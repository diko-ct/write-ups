import requests                                                                                                                                                                                                   
import urllib3                                                                                                                                                                                                    
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)                                                                                                                                               
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
headers = {"Accept": "application/json", "SEC":"d1ac2d48-531d-4cc1-b56e-583330db9227" , "Version":"22.0" , "Range":"items=0-"}                                                                                    
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
url = "https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources"                                                                                                             
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
response= requests.get(url , headers=headers,verify=False)                                                                                                                                                        
domains =[]                                                                                                                                                                                                       
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
#syslog msrpc wincollect                                                                                                                                                                                          
#{0, 59, 39}                                                                                                                                                                                                      
                                                                                                                                                                                                                  
for logsource in response.json():                                                                                                                                                                                 
    if logsource["type_id"] == 12 :                                                                                                                                                                               
        if logsource["protocol_type_id"] in (39 , 59):                                                                                                                                                            
            for parameter in logsource["protocol_parameters"]:                                                                                                                                                    
                if 'domain' in parameter['name'].lower():                                                                                                                                                         
                    domains.append(parameter['value'])                                                                                                                                                            
                                                                                                                                                                                                                  
print(set(domains))                                                                                                                                                                                               
                                                                                                                                                                                                                  
'''                                                                                                                                                                                                      
#{'', 'Jordan', 'jordan.housingbank.corp', 'SWIFT', 'dhousingbank.corp', 'JORDAN.HOUSINGBANK.CORP', 
#'swift.local', 'dhousingbank', 'Bahrain', 'palestine.housingbank.corp', 'HBK.COM.JO', 'hbk.com.jo','Palestine', 'HBTF-BH'}     

jordan.housingbank.corp = jordan.housingbank.corp,Jordan,JORDAN.HOUSINGBANK.CORP
palestine.housingbank.corp = palestine.housingbank.corp, Palestine
bahrain.housingbank.local = HBTF-BH,Bahrain
swift.local = SWIFT, swift.local
dhousingbank.corp = dhousingbank.corp, dhousingbank
hbk.com.jo = hbk.com.jo , HBK.COM.JO

#        for parameter in logsource["protocol_parameters"]:                                                                                                                                                       
#            if 'domain' in  parameter["name"].lower():                                                                                                                                                           
#                print(parameter["name"], parameter["value"])                                                                                                                                                     
'''