'''LinuxServer @ srvpnabappbd01
IBMAIXServer @ SRVPNABWAFIP01.palestine.housingbank.corp
WinCollect DSM - SRVPRMLFSP01  
LinuxServer @ SRVPNABRECD01 
WindowsAuthServer @ SRVPRMLSWSP01             
SRVPRMLDCMSP01 - 172.22.1.30
WinCollect DSM - SRVPRMLPDCP02 
WinCollect DSM - SRVPNABPDCD01 
WinCollect DSM - SRVPRMLPDCP01 
WindowsAuthServer @ SRVPRMLMBAMP01            
SRVPRMLDLPP01 - 172.22.116.2
SRVPRMLMBAMP01 @ 192.168.224.71
WindowsAuthServer @ SRVPRMLDCMSP01            
WindowsAuthServer @ SRVPRMLDLPP01             
SRVPRMLSEPP02 - 192.168.224.52 
SRVPRMLMNGEP01 @ 192.168.224.12
SRVPRMLDPMP01 @ 192.168.224.13 
SRVPRMLSEPP01 @ 192.168.224.51 
PS-DR-DC-FTD-PRI @ 192.168.236.2              
SRVPRMLKMSP01 @ 192.168.228.107
F5APM @ SRVPRMLWAFIP02.palestine.housingbank.corp       
SRVPRMLKMSP01 - 192.168.228.107
SRVPRMLBOSP01 @ 172.22.9.13 
SRVPRMLSEPP01 - 192.168.224.51 
PaSeries @ PAL-DR-external-PA-3020.hbtf.com.jo
WinCollect @ srvprmlsqlp02  
SRVPRMLBOSP01 - 172.22.9.13 
SRVPRMLSEPP02 @ 192.168.224.52 
LinuxServer @ SRVPNABWAFIP01.palestine.housingbank.corp 
SRVPNABSEPD01 @ 192.168.231.51 
LinuxServer @ srvpnabdbbd01
IBMAIXServer @ SRVPRMLWAFIP01.palestine.housingbank.corp
SRVPRMLFGWP03 - 172.22.100.242 
VmWare @ SRVPNABWAFIP01.palestine.housingbank.corp      
SRVPRMLDLPP01 @ 172.22.116.2
Forcepoint V Series @ SRVPNABWAFIP01.palestine.housingbank.corp
F5APM @ SRVPRMLWAFIP01.palestine.housingbank.corp       
F5ASM @ SRVPRMLWAFIP01.palestine.housingbank.corp       
PS-DR-Internet-FTD-PRI @ 192.168.236.1        
SRVPRMLTIMP01 @ 172.22.108.15  
SRVPRMLSWSP01 @ 192.168.223.23 
PS-HQ-Internet-FTD-PRI @ 192.168.222.1        
LinuxServer @ SRVPRMLWAFIP01.palestine.housingbank.corp 
WindowsAuthServer @ SRVPRMLFSP01              
PaSeries @ PAL-DR-internal-PA-3220.hbtf.com.jo
SRVPRMLFGWP03 @ 172.22.100.242 
SRVPRMLMNGEP01 - 192.168.224.12
SRVPRMLDPMP01 - 192.168.224.13 
IBMAIXServer @ SRVPNABWAFIP01.palestine.housingbank.corp
SRVPRMLMBAMP01 - 192.168.224.71
SRVPRMLSWSP01 - 192.168.223.23 
F5ASM @ SRVPNABWAFIP01.palestine.housingbank.corp       
Forcepoint V Series @ SRVPRMLWAFIP01.palestine.housingbank.corp
IBMAIXServer @ SRVPRMLWAFIP02.palestine.housingbank.corp
SRVPNABSEPD01 - 192.168.231.51 
Forcepoint V Series @ SRVPRMLWAFIP02.palestine.housingbank.corp
WinCollect @ SRVPRMLWASP01  
SRVPRMLDCMSP01 @ 172.22.1.30
WinCollect DSM - SRVPRMLSEPP02 
WinCollect @ SRVPRMLDHCPP01 
WinCollect DSM - SRVPRMLBOSP01 
VmWare @ SRVPNABRECD01      
F5APM @ SRVPNABWAFIP01.palestine.housingbank.corp       
SRVPNABDCMSD01 - 172.23.11.22  
LinuxServer @ SRVPRMLWAFIP02.palestine.housingbank.corp 
WinCollect DSM - SRVPRMLSEPP01 
IBMAIXServer @ SRVPRMLWAFIP01.palestine.housingbank.corp
PS-HQ-DC-FTD-PRI @ 192.168.222.3              
WinCollect DSM - SRVPRMLDLPP01 
Arbor Networks Pravail @ SRVPRMLARBP01        
WinCollect DSM - SRVPRMLDCMSP01
SRVPRMLTIMP01 - 172.22.108.15  
WinCollect DSM - SRVPNABSEPD01 
WinCollect DSM - SRVPNABDCMSD01
WinCollect DSM - SRVPRMLDHCPP02
WinCollect DSM - SRVPRMLTIMP01 
WinCollect DSM - SRVPRMLSWSP01 
WinCollect DSM - SRVPRMLDPMP01 
WinCollect DSM - SRVPRMLMNGEP01
WinCollect DSM - SRVPRMLKMSP01 
WinCollect DSM - SRVPRMLMBAMP01
LinuxServer @ SRVPRMLAECCP01
WinCollect DSM - SRVPRMLFGWP03 
IBMAIXServer @ SRVPRMLWAFIP02.palestine.housingbank.corp'''

import requests                                                                                                                                                                                                   
import urllib3                                                                                                                                                                                                    
import json                                                                                                                                                                                                       
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)                                                                                                                                               
headers = {"Accept": "application/json", "SEC":"d1ac2d48-531d-4cc1-b56e-583330db9227" , "Version":"22.0"}                                                                                                         
url = "https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources"                                                                                                             
response= requests.get(url , headers=headers,verify=False)                                                                                                                                                        
dict1={'1':105502, '2':105503, '3':105504, '4':105505, '5':105506}                                                                                                                                                
l = open('Bahrain_Asset.csv' , 'r').read().split('\n')[:-1]                                                                                                                                                       
print('-'*343)                                                                                                                                                                                                    
for logsource in response.json():                                                                                                                                                                                 
    for server in l :                                                                                                                                                                                             
        if ( ' '.join(server.split(',')[:-2]).lower().strip(' ') in  logsource['name'].lower().strip(' ') or ' '.join(server.split(',')[-2]).lower().strip(' ') in  logsource['name'].lower().strip(' ')) and not 
( server.split(',')[:-2]==' '   or len(' '.join(server.split(',')[:-2]).lower().strip(' ')) < 5       ) :                                                                                                         
                                                                                                                                                                                                                  
            group_ids = logsource['group_ids']                                                                                                                                                                    
            if 0 in group_ids:                                                                                                                                                                                    
                group_ids.remove(0)                                                                                                                                                                               
            group_ids = group_ids+[dict1[server.split(',')[-1]]]                                                                                                                                                  
            print(logsource['name'])                                                                                                                                                                              
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
            requests.post(f"{url}/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids  } ,verify=False)                                                                                           
            break