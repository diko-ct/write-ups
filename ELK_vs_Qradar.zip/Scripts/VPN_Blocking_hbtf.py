import requests
import urllib3 
import json    
import sys
from datetime import datetime
import os 
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


JordanFMCIPs= ['172.31.80.3','172.18.80.80']
PalestineFMCIPs= ['172.22.135.5' , '172.22.135.4']
Blocked_IPs =[]
##################### SIEM ###########################
def SIEMRefSet():
    headers = {"Accept": "application/json", "SEC": "03e9f245-3426-4f99-a37e-24b6aaf74a09" , "Version":"22.0"} 
    AllIPs= []
    SIEMUrl='https://qradar-console.hbtf.com.jo/api/reference_data/sets/'
    name = "HBTF_VPN Brute Force auto temp block - 12 attempts in 6 hours List"
    request = requests.get(f'{SIEMUrl}{name}' , headers=headers , verify=False)
    if request.json().get('data', None) :
        IPs = [IP['value'] for IP in request.json()['data']]
        AllIPs.extend(IPs)
    name = "HBTF_VPN Brute Force auto temp block - 8 attempts in 3 hours List"    
    request = requests.get(f'{SIEMUrl}{name}' , headers=headers , verify=False)
    if request.json().get('data',None) : 
        IPs = [IP['value'] for IP in request.json()['data']]
        AllIPs.extend(IPs)
    return AllIPs

###################### FMC Jordan  ###############################
def JordanFMCGenerateToken(JordanFMCIPs = JordanFMCIPs) : 
    headers_jo = {'Authorization': 'Basic c2llbTpsXWRrbUhnd2dobTtAMjAyNQ', 'accept': 'application/json'}

    for IP in JordanFMCIPs: 
        response_jo = requests.post(f'https://{IP}/api/fmc_platform/v1/auth/generatetoken', headers=headers_jo, verify=False)
        response_jo.raise_for_status()
        if response_jo.status_code ==204 : 
            access_token_jo = response_jo.headers.get('X-auth-access-token')
            return IP, access_token_jo, '3890A56F-0696-0ed3-0001-202592173483'
    if not access_token_jo :
        log_file.write(f'Critical Issue, FMC Jordan')
        return 'Error, Something wrong on jordan'

###################### FMC Palestine  ###############################  

def PalestineFMCGenerateToken(PalestineFMCIPs = PalestineFMCIPs) : 
    headers_pal = {'Authorization': f'Basic Sk8tSVI6SjAhcjEyMzQ1Nis=', 'accept': 'application/json'}
    for IP in PalestineFMCIPs : 
        response_pal = requests.post(f'https://{IP}/api/fmc_platform/v1/auth/generatetoken', headers=headers_pal, verify=False)
        response_pal.raise_for_status()
        if response_pal.status_code ==204 : 
            access_token_pal = response_pal.headers.get('X-auth-access-token')
            return IP, access_token_pal, '005056BC-03A7-0ed3-0000-304942683458'
    if not access_token_pal :
        log_file.write(f'Critical Issue, FMC Palestine')
        return 'Error, Something wrong on palestine'

###################### FMC Jordan/Palestine List IPs ###########################
# Response if there are no ips   
#{'links': {}, 'paging': {'offset': 0, 'limit': 0, 'count': 0, 'pages': 0}}   
# Response if there are ips
# {'links': {'self': 'https://172.31.80.3/api/fmc_config/v1/domain/e276abec-e0f2-11e3-8169-6d9ed49b625f/object/dynamicobjects/3890A56F-0696-0ed3-0001-202592173483/mappings?offset=0&limit=25'}, 'items': [{'maping': '192.168.1.1'}, {'mapping': '192.168.2.1'}], 'paging': {'offset': 0, 'limit': 25, 'count': 2, 'pages': 1}}



def FMCblocklist(IP,access_token, object_id):



    url = f"https://{IP}/api/fmc_config/v1/domain/e276abec-e0f2-11e3-8169-6d9ed49b625f/object/dynamicobjects/{object_id}/mappings"
    headers = {"accept": "application/json","X-auth-access-token": access_token}
    params = {'offset' : 0 , 'limit':1000}
 
    while True: 
        response = requests.get(url, headers=headers, verify=False)
        if response.json().get('items' , None) :
            for ip in response.json()['items'] :
                Blocked_IPs.append(ip['mapping'])

        if response.json().get('paging',None).get('next' , None):
            params['offset'] +=1000
        else :  
            break
    return 0


def Listdiff(AllIPs, Blocked_IPs=Blocked_IPs):


    if len(AllIPs) == 0  and len(Blocked_IPs) == 0 : 
        IPsneedtobeblocked = []
        IPsneedtobereleased = []
    elif len(AllIPs) == 0 and len(Blocked_IPs) != 0 :
        IPsneedtobeblocked = []
        IPsneedtobereleased = Blocked_IPs
    elif len(AllIPs) != 0 and len(Blocked_IPs) == 0 :
        IPsneedtobeblocked  = AllIPs 
        IPsneedtobereleased = []
    else :
        IPsneedtobeblocked = list(set(AllIPs) - set(Blocked_IPs))
        IPsneedtobereleased = list(  set(Blocked_IPs) - set(AllIPs))
    return IPsneedtobeblocked, IPsneedtobereleased



def IPsrelease(IP, access_token,IPsneedtobereleased , object_id): 
    if not IPsneedtobereleased : 
        return 0
    url = f"https://{IP}/api/fmc_config/v1/domain/e276abec-e0f2-11e3-8169-6d9ed49b625f/object/dynamicobjectmappings" 
    headers = {"accept": "application/json","Content-Type": "application/json","X-auth-access-token": access_token} 
    for ip in IPsneedtobereleased :
        data_remove= {"remove": [{"mappings": ["{}".format(ip)],"dynamicObject": {"id": "{}".format(object_id),"type": "DynamicObject"}}]}
        response = requests.post(url, headers=headers, json=data_remove, verify=False)
    return 0


def IPsblock(IP, access_token ,IPsneedtobeblocked, object_id): 
    if not IPsneedtobeblocked :
        return 0 
    url = f"https://{IP}/api/fmc_config/v1/domain/e276abec-e0f2-11e3-8169-6d9ed49b625f/object/dynamicobjectmappings" 
    headers = {"accept": "application/json","Content-Type": "application/json","X-auth-access-token": access_token} 
    for ip in IPsneedtobeblocked :
        data_add= {"add": [{"mappings": ["{}".format(ip)],"dynamicObject": {"id": "{}".format(object_id),"type": "DynamicObject"}}]}
        response = requests.post(url, headers=headers, json=data_add, verify=False)
    return 0

def main(): 
    try : 
        log_file = LogFile()
        IP_jo, access_token_jo , object_id_jo = JordanFMCGenerateToken()
        IP_pal , access_token_pal, object_id_pal = PalestineFMCGenerateToken()
        AllIPs = SIEMRefSet()
        FMCblocklist(IP_jo,access_token_jo, object_id_jo)
        FMCblocklist(IP_pal,access_token_pal, object_id_pal)
        IPsneedtobeblocked, IPsneedtobereleased = Listdiff(AllIPs, Blocked_IPs)
        IPsrelease(IP_jo , access_token_jo , IPsneedtobereleased , object_id_jo)
        IPsrelease(IP_pal , access_token_pal , IPsneedtobereleased , object_id_pal)
        IPsblock(IP_jo, access_token_jo , IPsneedtobeblocked, object_id_jo)
        IPsblock(IP_pal, access_token_pal , IPsneedtobeblocked, object_id_pal)
        log_file.write(f'IPs released : {IPsneedtobereleased}\n')
        log_file.write(f'IPs blocked : {IPsneedtobeblocked}\n')
    except :
        pass 



def LogFile():
    full_path= f'/store/scripts/VPN_Bruteforce_logs/script_{datetime.now().strftime("%Y_%m_%d")}.txt'
    if os.path.exists(full_path):
        mode = "a"  # Append to existing
    else:
        mode = "w"
    log_file = open(full_path , mode)
    log_file.write(f'[{datetime.now()}] Script execution started.\n')
    return log_file


if __name__ == "__main__":
    main()