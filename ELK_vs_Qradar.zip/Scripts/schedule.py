from datetime import datetime, timedelta
import csv

class ShiftScheduler:
    def __init__(self, start_date, num_weeks, people, unavailable_dates):
        """
        Initialize the shift scheduler.
        
        Args:
            start_date (str): Start date in 'YYYY-MM-DD' format
            num_weeks (int): Number of weeks to schedule
            people (list): List of person names
            unavailable_dates (dict): Dictionary with person names as keys and list of unavailable dates as values
                                     Format: {'Person 1': ['2024-01-15', '2024-01-20'], ...}
        """
        self.start_date = datetime.strptime(start_date, '%Y-%m-%d')
        self.num_weeks = num_weeks
        self.people = people
        self.unavailable_dates = unavailable_dates
        self.schedule = []
        self.stats = {person: {'total': 0, 'weekends': 0} for person in people}
        
    def is_weekend(self, date):
        """Check if date is Thursday (3), Friday (4), or Saturday (5)"""
        return date.weekday() in [3, 4, 5]
    
    def is_available(self, person, date_str):
        """Check if a person is available on a given date"""
        return date_str not in self.unavailable_dates.get(person, [])
    
    def get_available_people(self, date_str):
        """Get list of people available on a given date"""
        return [person for person in self.people if self.is_available(person, date_str)]
    
    def generate_schedule(self):
        """Generate the shift schedule based on criteria"""
        total_days = self.num_weeks * 7
        last_assigned = None
        
        for day_offset in range(total_days):
            current_date = self.start_date + timedelta(days=day_offset)
            date_str = current_date.strftime('%Y-%m-%d')
            day_name = current_date.strftime('%a')
            is_weekend_day = self.is_weekend(current_date)
            
            # Get available people for this date
            available_people = self.get_available_people(date_str)
            
            if not available_people:
                raise ValueError(f"No one is available on {date_str}. Please adjust unavailable dates.")
            
            # Filter out the person who worked yesterday (no consecutive days)
            candidates = [person for person in available_people if person != last_assigned]
            
            # If everyone worked yesterday or only one person available, use all available
            if not candidates:
                candidates = available_people
            
            # Select person based on criteria
            if is_weekend_day:
                # For weekends, choose person with fewest weekend shifts
                selected_person = min(candidates, key=lambda p: self.stats[p]['weekends'])
            else:
                # For weekdays, choose person with fewest total shifts
                selected_person = min(candidates, key=lambda p: self.stats[p]['total'])
            
            # Update schedule and statistics
            self.schedule.append({
                'date': date_str,
                'day': day_name,
                'person': selected_person,
                'is_weekend': is_weekend_day
            })
            
            self.stats[selected_person]['total'] += 1
            if is_weekend_day:
                self.stats[selected_person]['weekends'] += 1
            
            last_assigned = selected_person
        
        return self.schedule
    
    def print_schedule(self):
        """Print the schedule in a readable format"""
        print("\n" + "="*70)
        print("24-HOUR SHIFT SCHEDULE (8 AM - 8 AM)")
        print("="*70)
        print(f"{'Date':<12} {'Day':<5} {'Assigned Person':<20} {'Weekend':<10}")
        print("-"*70)
        
        for shift in self.schedule:
            weekend_marker = "✓" if shift['is_weekend'] else ""
            print(f"{shift['date']:<12} {shift['day']:<5} {shift['person']:<20} {weekend_marker:<10}")
        
        print("="*70)
        print("\nSTATISTICS:")
        print("-"*70)
        for person in self.people:
            print(f"{person}:")
            print(f"  Total Shifts: {self.stats[person]['total']}")
            print(f"  Weekend Shifts: {self.stats[person]['weekends']}")
            print()
    
    def export_to_csv(self, filename='shift_schedule.csv'):
        """Export schedule to CSV file"""
        with open(filename, 'w', newline='') as csvfile:
            fieldnames = ['Date', 'Day', 'Assigned Person', 'Weekend']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for shift in self.schedule:
                writer.writerow({
                    'Date': shift['date'],
                    'Day': shift['day'],
                    'Assigned Person': shift['person'],
                    'Weekend': 'Yes' if shift['is_weekend'] else 'No'
                })
        
        print(f"Schedule exported to {filename}")


# Example usage
if __name__ == "__main__":
    # Configuration
    start_date = "2026-01-01"  # Start date (YYYY-MM-DD)
    num_weeks = 4               # Number of weeks to schedule
    people = ["Diknash", "Doulat", "Majdi"]
    
    # Unavailable dates for each person
    # Format: {'Person Name': ['YYYY-MM-DD', 'YYYY-MM-DD'], ...}
    unavailable_dates = {
        "Person 1": [],
        "Person 2": [],
        "Person 3": []
    }
    
    # Create scheduler and generate schedule
    try:
        scheduler = ShiftScheduler(start_date, num_weeks, people, unavailable_dates)
        scheduler.generate_schedule()
        scheduler.print_schedule()
        scheduler.export_to_csv()
    except ValueError as e:
        print(f"Error: {e}")