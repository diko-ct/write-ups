from datetime import datetime, timedelta
import csv

class ShiftScheduler:
    def __init__(self, start_date, num_weeks, people, unavailable_dates):
        """
        Initialize the shift scheduler.
        
        Args:
            start_date (str): Start date in 'YYYY-MM-DD' format
            num_weeks (int): Number of weeks to schedule
            people (list): List of person names
            unavailable_dates (dict): Dictionary with person names as keys and list of unavailable dates as values
                                     Format: {'Person 1': ['2024-01-15', '2024-01-20'], ...}
        """
        self.start_date = datetime.strptime(start_date, '%Y-%m-%d')
        self.num_weeks = num_weeks
        self.people = people
        self.unavailable_dates = unavailable_dates
        self.schedule = []
        self.stats = {person: {'total': 0, 'weekends': 0, 'primary': 0, 'secondary': 0, 'third': 0} for person in people}
        
    def is_weekend(self, date):
        """Check if date is Thursday (3), Friday (4), or Saturday (5)"""
        return date.weekday() in [3, 4, 5]
    
    def is_available(self, person, date_str):
        """Check if a person is available on a given date"""
        return date_str not in self.unavailable_dates.get(person, [])
    
    def get_available_people(self, date_str):
        """Get list of people available on a given date"""
        return [person for person in self.people if self.is_available(person, date_str)]
    
    def assign_backups(self, primary_person, date_str, available_people):
        """
        Assign secondary and third backup based on availability and balance.
        Order: Primary -> Secondary -> Third
        """
        # Get people other than primary
        others = [p for p in available_people if p != primary_person]
        
        if len(others) == 0:
            return None, None
        elif len(others) == 1:
            return others[0], None
        
        # Sort by number of times they've been secondary backup
        others_sorted = sorted(others, key=lambda p: (
            self.stats[p]['secondary'],
            self.stats[p]['third']
        ))
        
        secondary = others_sorted[0]
        third = others_sorted[1] if len(others_sorted) > 1 else None
        
        return secondary, third
    
    def generate_schedule(self):
        """Generate the shift schedule based on criteria"""
        total_days = self.num_weeks * 7
        last_assigned = None
        
        for day_offset in range(total_days):
            current_date = self.start_date + timedelta(days=day_offset)
            date_str = current_date.strftime('%Y-%m-%d')
            day_name = current_date.strftime('%a')
            is_weekend_day = self.is_weekend(current_date)
            
            # Get available people for this date
            available_people = self.get_available_people(date_str)
            
            if not available_people:
                raise ValueError(f"No one is available on {date_str}. Please adjust unavailable dates.")
            
            # Filter out the person who worked yesterday (no consecutive days)
            candidates = [person for person in available_people if person != last_assigned]
            
            # If everyone worked yesterday or only one person available, use all available
            if not candidates:
                candidates = available_people
            
            # Select primary person based on criteria
            if is_weekend_day:
                # For weekends, choose person with fewest weekend shifts
                primary_person = min(candidates, key=lambda p: self.stats[p]['weekends'])
            else:
                # For weekdays, choose person with fewest total shifts
                primary_person = min(candidates, key=lambda p: self.stats[p]['total'])
            
            # Assign backups
            secondary_person, third_person = self.assign_backups(primary_person, date_str, available_people)
            
            # Update schedule
            self.schedule.append({
                'date': date_str,
                'day': day_name,
                'primary': primary_person,
                'secondary': secondary_person,
                'third': third_person,
                'is_weekend': is_weekend_day
            })
            
            # Update statistics
            self.stats[primary_person]['total'] += 1
            self.stats[primary_person]['primary'] += 1
            if is_weekend_day:
                self.stats[primary_person]['weekends'] += 1
            
            if secondary_person:
                self.stats[secondary_person]['secondary'] += 1
            
            if third_person:
                self.stats[third_person]['third'] += 1
            
            last_assigned = primary_person
        
        return self.schedule
    
    def print_schedule(self):
        """Print the schedule in a readable format"""
        print("\n" + "="*90)
        print("24-HOUR SHIFT SCHEDULE (8 AM - 8 AM)")
        print("="*90)
        print(f"{'Date':<12} {'Day':<5} {'Primary':<15} {'Secondary':<15} {'Third':<15} {'Weekend':<8}")
        print("-"*90)
        
        for shift in self.schedule:
            weekend_marker = "✓" if shift['is_weekend'] else ""
            secondary = shift['secondary'] if shift['secondary'] else "-"
            third = shift['third'] if shift['third'] else "-"
            print(f"{shift['date']:<12} {shift['day']:<5} {shift['primary']:<15} {secondary:<15} {third:<15} {weekend_marker:<8}")
        
        print("="*90)
        print("\nSTATISTICS:")
        print("-"*90)
        for person in self.people:
            print(f"{person}:")
            print(f"  Total Primary Shifts: {self.stats[person]['total']}")
            print(f"  Weekend Primary Shifts: {self.stats[person]['weekends']}")
            print(f"  Times as Primary: {self.stats[person]['primary']}")
            print(f"  Times as Secondary: {self.stats[person]['secondary']}")
            print(f"  Times as Third: {self.stats[person]['third']}")
            print()
    
    def export_to_csv(self, filename='shift_schedule.csv'):
        """Export schedule to CSV file"""
        with open(filename, 'w', newline='') as csvfile:
            fieldnames = ['Date', 'Day', 'Primary', 'Secondary', 'Third', 'Weekend']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for shift in self.schedule:
                writer.writerow({
                    'Date': shift['date'],
                    'Day': shift['day'],
                    'Primary': shift['primary'],
                    'Secondary': shift['secondary'] if shift['secondary'] else '-',
                    'Third': shift['third'] if shift['third'] else '-',
                    'Weekend': 'Yes' if shift['is_weekend'] else 'No'
                })
        
        print(f"Schedule exported to {filename}")


# Example usage
if __name__ == "__main__":
    # Configuration
    start_date = "2024-01-08"  # Start date (YYYY-MM-DD)
    num_weeks = 4               # Number of weeks to schedule
    people = ["Diknash", "Doulat", "Majdi"]
    
    # Unavailable dates for each person
    # Format: {'Person Name': ['YYYY-MM-DD', 'YYYY-MM-DD'], ...}
    unavailable_dates = {
        "Person 1": [],
        "Person 2": [],
        "Person 3": []
    }
    
    # Create scheduler and generate schedule
    try:
        scheduler = ShiftScheduler(start_date, num_weeks, people, unavailable_dates)
        scheduler.generate_schedule()
        scheduler.print_schedule()
        scheduler.export_to_csv()
    except ValueError as e:
        print(f"Error: {e}")