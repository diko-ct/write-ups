import sys
import json 
import requests 
import os 


access_token_jo=os.popen("curl --request POST 'https://172.31.80.3/api/fmc_platform/v1/auth/generatetoken' --header 'Authorization: Basic c2llbTpsXWRrbUhnd2dobTtAMjAyNQ==' -k -i | grep -i X-auth-access-token|awk -F': ' '{ print $2 }'|head -c -1").read()[:-1] 

access_token_pal=os.popen("curl --request POST 'https://172.22.135.5/api/fmc_platform/v1/auth/generatetoken' --header 'Authorization: Basic Sk8tSVI6SjAhcjEyMzQ1Nis=' -k -i | grep -i X-auth-access-token|awk -F': ' '{ print $2 }'|head -c -1").read()[:-1] 

data_add_jo={"add": [{"mappings": ["{}".format(sys.argv[1])],"dynamicObject": {"id": "{}".format("3890A56F-0696-0ed3-0001-202592173483"),"type": "DynamicObject"}}]}

data_add_pal={"add": [{"mappings": ["{}".format(sys.argv[1])],"dynamicObject": {"id": "{}".format("005056BC-03A7-0ed3-0000-304942683458"),"type": "DynamicObject"}}]} 

data_remove_jo={"remove": [{"mappings": ["{}".format(sys.argv[1])],"dynamicObject": {"id": "{}".format("3890A56F-0696-0ed3-0001-202592173483"),"type": "DynamicObject"}}]} 

data_remove_pal={"remove": [{"mappings": ["{}".format(sys.argv[1])],"dynamicObject": {"id": "{}".format("005056BC-03A7-0ed3-0000-304942683458"),"type": "DynamicObject"}}]}

os.system("curl -k -X 'POST' 'https://{}/api/fmc_config/v1/domain/{}/object/dynamicobjectmappings' -H 'accept: application/json' -H 'Content-Type: application/json' -H 'X-auth-access-token: {}' -d '{}'".format("172.31.80.3","e276abec-e0f2-11e3-8169-6d9ed49b625f
",access_token_jo,json.dumps(data_add_jo))) 

os.system("curl -k -X 'POST' 'https://{}/api/fmc_config/v1/domain/{}/object/dynamicobjectmappings' -H 'accept: application/json' -H 'Content-Type: application/json' -H 'X-auth-access-token: {}' -d '{}'".format("172.22.135.5","e276abec-e0f2-11e3-8169-6d9ed49b625
f",access_token_pal,json.dumps(data_add_pal)))

os.system("(sleep 20; curl -k -X 'POST' 'https://{}/api/fmc_config/v1/domain/{}/object/dynamicobjectmappings' -H 'accept: application/json' -H 'Content-Type: application/json' -H 'X-auth-access-token: {}' -d '{}') &".format("172.31.80.3","e276abec-e0f2-11e3-816
9-6d9ed49b625f",access_token_jo,json.dumps(data_remove_jo))) 

os.system("(sleep 20; curl -k -X 'POST' 'https://{}/api/fmc_config/v1/domain/{}/object/dynamicobjectmappings' -H 'accept: application/json' -H 'Content-Type: application/json' -H 'X-auth-access-token: {}' -d '{}') &".format("172.22.135.5","e276abec-e0f2-11e3-81
69-6d9ed49b625f",access_token_pal,json.dumps(data_remove_pal)))