"""
ec-Jordan :: SRVJVIRSCOLP02 = 108
eventcollector136 :: Palestine-Collector = 136
eventcollector0 :: qradar-console = 7
eventcollector149 :: JordanCol02 = 149
eventcollector163 :: DR-Collector = 163
"""
191 = palestine log sources
89 = dr log sources                                                                                                                                                                                                                
52 = jordancol log sources 
2240 = srv log sources 
64 = console log sources  


JordanCol02 do not have bahrain log sources 


import requests                                                                                                                                                                                                   
import urllib3                                                                                                                                                                                                    
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)                                                                                                                                               
headers = {"Accept": "application/json", "SEC":"d1ac2d48-531d-4cc1-b56e-583330db9227" ,"Version":"22.0"}                                                                                                          
url = "https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources"                                                                                                             
response= requests.get(url , headers=headers,verify=False)                                                                                                                                                        
                                                                                                                                                                                                                  
for logsource in response.json():                                                                                                                                                                                 
    if logsource['target_event_collector_id'] == 136 :                                                                                                                                                            
        group_ids = logsource['group_ids']                                                                                                                                                                    
        if 0 in group_ids:                                                                                                                                                                                        
             group_ids.remove(0)                                                                                                                                                                                  
        group_ids = group_ids+[105483]                                                                                                                                                                            
        requests.post(f"{url}/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)                                                                                                
        print(logsource['name'] , group_ids )

for logsource in response.json():                                                                                                                                                                                 
    if logsource['target_event_collector_id'] == 163 :                                                                                                                                                            
        group_ids = logsource['group_ids']                                                                                                                                                                        
        if 0 in group_ids:                                                                                                                                                                                        
            group_ids.remove(0)                                                                                                                                                                                   
        group_ids= group_ids + [105482]                                                                                                                                                                           
        requests.post(f"{url}/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)                                                                                                
        print(logsource['name'] , group_ids )

for logsource in response.json():                                                                                                                                                                                 
    if logsource['target_event_collector_id'] == 149  :                                                                                                                                                           
        for ip in bahrain_ips:                                                                                                                                                                                    
            if ip.strip().lower() in logsource['name'].strip().lower():                                                                                                                                           
                print(logsource['name'])                                                                                                                                                                          
        for hostname in bahrain_hostnames :                                                                                                                                                                       
            if hostname.strip().lower() in logsource['name'].strip().lower():                                                                                                                                     
                print(logsource['name'])                                                                                                                                                                          
        for subnet in bahrain_subnets :                                                                                                                                                                           
            if subnet.strip().lower() in logsource['name'].strip().lower():                                                                                                                                       
                print(logsource['name'])     



bahrain_ips = '''10.217.7.5 10.217.7.6 10.217.6.5 10.217.6.6 10.217.10.5 172.31.34.6 10.100.1.216 10.100.1.236 10.100.1.218 172.24.0.2 192.168.22.2 10.1.251.9 10.100.1.100 10.100.1.101 10.101.1.3 10.100.1.224 10.100.1.238 10.100.1.204 10.100.1.203 10.40.10.2 10.40.11.2 10.100.1.229 10.100.251.10 10.30.32.2 10.30.31.2 10.30.32.4 1.100.1.237 10.101.1.11 10.100.1.227 10.100.1.228 10.101.1.10 10.30.34.2 10.30.33.2 10.100.251.12 10.97.1.4 10.95.1.4 10.97.1.6 10.95.1.6 10.97.10.5 10.95.10.5 10.97.1.5 10.95.1.5 10.100.251.8 10.100.251.11 10.110.1.3 10.100.1.208 10.120.1.10 10.100.1.231 10.100.1.206 10.11.11.6 10.11.11.5 10.11.12.5 10.11.12.8 10.11.12.12 10.100.1.240 10.100.1.241 192.168.23.30 10.11.12.30 10.11.12.31 10.11.12.32 10.11.12.33 10.11.12.34 10.11.12.35 10.11.12.36 10.11.12.39 10.11.12.40 10.11.12.37 192.168.23.20 192.168.23.21 10.101.1.253 192.168.23.5 192.168.23.6 10.201.3.1 192.168.23.22 192.168.23.23 192.168.30.2 172.17.17.21 10.200.3.1 172.17.17.20 192.168.200.1 84.255.145.65 192.168.31.2 192.168.25.1 84.255.145.86 10.100.1.112 10.100.1.113 10.100.1.253 172.25.0.7 10.100.1.117 10.100.1.115 10.100.1.111 192.168.23.10 10.100.1.114 10.100.1.116 192.168.23.8 10.101.1.50 10.100.1.212 10.101.1.4 10.100.1.214 192.168.23.40 192.168.23.41 10.101.1.31'''.split(' ')
bahrain_hostnames = '''SRVBMNMCORAPH SRVBMNMCORAPP2 srvbmnmcordb1 srvbmnmcordb2 SRVBMNCORDADR DBDR SRVBMNMCORETEST SRVBMNMCORETEST SRVBMNMCORETEST SRVBMNMIBSAP SRVBMNMIBSDB SRVBMNMIBSTS SRVBHODCP01 SRVBHODCP02 SRVBDRDCD03 SRVBMNMDWHAPTST SRVBMNMDWHDBTST SRVBMNMDWH02 SRVBMNMDWH01 SRVBMNMDWHAPP SRVBMNMDWHDB SRVBMNMTMSXAPP SRVBMNMOBGT SRVBMNMTMSXAPP01 SRVBMNMTMSXDBP BMNMSRVTMSGW SRVBMNMHV00 SRVBMNMHV01 SRVBMNMHV03 SRVBMNMHV04 SRVBMNMHV02 SRVBMNMECAPPROD SRVBMNMECDBPROD SRVBMNMECCTST SRVBMNMEFAP SRVBMNMEFTSDP SRVBMNMHAEFA SRVBMNMHAEFDB SRVBMNMDREFA SRVBMNMDREFDB SRVBMNMEFAP2 SRVBMNMEFTSDb2 SRVBMNMEFTST1 SRVBMNMEFTST2 WIN-9BFG3NR6PRN SRVBMNMATTS1 SRVBMNMDLO01 SRVBMNMWINCOL SRVBMNMDFS01 WSBB501NWA01 WSBB501NWA01 SRVBMNMFIREMON SRVBMNMGRDCOL1 SRVBMNMGRDCOL2 SRVBVIRPAMP01 SRVBVIRPAMP02 SRVBVIRPAMP03 SRVBVIRPAMP04 SRVBVIRPAMP05 SRVBVIRPAMP06 SRVBVIRPAMP07 SRVBVIRPAMP08 SRVBVIRPAMP09 SRVBVIRPAMP10 BHHO-PA3020-PMY BHHO-PA3020-SEC BHDR-PA850 BHHO-DRLL-RTR1 BHHO-AMN-RTR2 BHHO-SINAND-RTR BHHO-AMN-RTR1-CME BHHO-ATM-RTR BHHO-INET-RTR2 BHDR-HOLL-RTR1 BHHO-FTD-INETSW1 BHHO-FTD-DMZSW1 BHHO-PA-DMZ-SW1 BHHO-PA-ASW01 BHHO-PA-CSW01 BHHO-PA-UNTST-SW1 BHHO-FTD-TSTSW1 BHHO-PA-ASW02 BHHO-PA-ASW03 BHHO-PA-SW04 BHHO-PA-SW05 BHHO-PA-SW06 BHHO-PA-DMZ-SW2 BHDR-PA-ASW01 SRVBMNMBKSP SRVBMNMBKSD'''.split('')
bahrain_subnets = '''10.217.7 10.217.6 10.217.10 172.31.34 10.100.1 172.24.0 192.168.22 10.1.251 10.101.1 10.40.10 10.40.11 10.100.251 10.30.32 10.30.31 1.100.1 10.30.34 10.30.33 10.97.1 10.95.1 10.97.10 10.95.10 10.110.1 10.120.1 10.11.11 10.11.12 192.168.23 10.201.3 192.168.30 172.17.17 10.200.3 192.168.200 84.255.145 192.168.31 192.168.25 172.25.0'''.split(' ')


for logsource in response.json():                                                                                                                                                                                 
    c=0                                                                                                                                                                                                           
    if logsource['target_event_collector_id'] == 149  :                                                                                                                                                           
        for ip in bahrain_ips:                                                                                                                                                                                    
            if ip.strip().lower() in logsource['name'].strip().lower():                                                                                                                                           
                print(logsource['name'])                                                                                                                                                                          
                c=1                                                                                                                                                                                               
                break                                                                                                                                                                                             
        for hostname in bahrain_hostnames :                                                                                                                                                                       
            if hostname.strip().lower() in logsource['name'].strip().lower():                                                                                                                                     
                print(logsource['name'])                                                                                                                                                                          
                c=1                                                                                                                                                                                               
                break                                                                                                                                                                                             
        for subnet in bahrain_subnets :                                                                                                                                                                           
            if subnet.strip().lower() in logsource['name'].strip().lower():                                                                                                                                       
                print(logsource['name'])                                                                                                                                                                          
                c=1                                                                                                                                                                                               
                break                                                                                                                                                                                             
        if c ==1 :                                                                                                                                                                                                
            break                                                                                                                                                                                                 
        group_ids = logsource['group_ids']                                                                                                                                                                        
        if 0 in group_ids:                                                                                                                                                                                        
            group_ids.remove(0)                                                                                                                                                                                   
        group_ids = group_ids+[105482]                                                                                                                                                                            
        requests.post(f"{url}/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)                                                                                                
        print(logsource['name'] , group_ids )