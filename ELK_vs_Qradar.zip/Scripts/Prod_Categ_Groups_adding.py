import requests                                                                                         
import urllib3                                                                                          
import json                                                                                             
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)                                     
headers = {"Accept": "application/json", "SEC":"d1ac2d48-531d-4cc1-b56e-583330db9227" , "Version":"22.0"
}                                                                                                       
url = "https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources"   
response= requests.get(url , headers=headers,verify=False)                                              
l = open('Assets.csv' , 'r').read().split('\n')                                                         
for logsource in response.json():                                                                       
    for server in l :                                                                                   
        if ( ' '.join(server.split(',')[:-2]).lower().strip(' ') in  logsource['name'].lower().strip(' ') or ' '.join(server.split(',')[-2]).lower().strip(' ') ==  logsource['name'].lower().strip(' ')) and not ( server.split(',')[:-2]==' '   or len(' '.join(server.split(',')[:-2]).lower().strip(' ')) < 5 ) :
            