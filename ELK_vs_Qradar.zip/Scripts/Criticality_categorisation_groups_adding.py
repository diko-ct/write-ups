#added servers
'''
OracleDbAudit @ qbibsora1 [105484, 105502] 1                                                                                                                                                                      
BHHO-PA-CSW01 @ 10.11.18.2 [104675, 105484, 104726, 104677, 105505] 4                                                                                                                                             
F5ASM @ HBTFLTMEXT02.bahrain.housingbank.local [104727, 104677, 104675, 105504] 3                                                                                                                                 
F5APM @ pbbankapp1 [105484, 105504] 3                                                                                                                                                                             
BHHO-SINAND-RTR @ 192.168.28.3 [105484, 104675, 104677, 104726, 105506] 5                                                                                                                                         
PostFixMailTransferAgent @ qbbankora1 [105484, 105502] 1                                                                                                                                                          
PostFixMailTransferAgent @ qbibsweb1 [105484, 105502] 1                                                                                                                                                           
IBMAIXServer @ HBTFLTMEXT02.bahrain.housingbank.local [104675, 104727, 104677, 105484, 105504] 3                                                                                                                  
Forcepoint V Series @ HBTFLTMEXT02.bahrain.housingbank.local [104675, 104727, 104677, 105504] 3                                                                                                                   
PostFixMailTransferAgent @ qbibsapp1 [105484, 105502] 1                                                                                                                                                           
BHHO-FTD-INETSW1 @ 10.11.18.20 [104675, 104677, 104726, 105484, 105506] 5                                                                                                                                         
BHHO-FTD-INETSW1 @ 10.11.18.20 [104675, 104677, 104726, 105484, 105505] 4                                                                                                                                         
BHHO-SER-SW02 @ 10.11.18.22 [104677, 105484, 104726, 104675, 105505] 4                                                                                                                                            
BHHO-PADMZ-SW2 @ 10.11.18.16 [104726, 100099, 104675, 104677, 105503] 2                                                                                                                                           
F5LTM @ HBTFLTMEXT02.bahrain.housingbank.local [105484, 104727, 104677, 104675, 105504] 3                                                                                                                         
IBMAIXServer @ pbibsapp1 [105484, 105504] 3                                                                                                                                                                       
VmWare @ HBTFLTMEXT01.bahrain.housingbank.local [104677, 104727, 104675, 105505] 4                                                                                                                                
BHHO-SER-SW01 @ 10.11.18.21 [104677, 104675, 105484, 104726, 105505] 4                                                                                                                                            
Certificate Authority    @ SRVBMNMICAP01 - 10.11.15.14 [104729, 104677, 105497, 105484, 104675, 105504]                                                                                                           
BHHO-MGMT-SW @ 10.11.18.5 [104675, 105484, 104726, 104677, 105503] 2                                                                                                                                              
OracleDbAudit @ qbbankora2 [105484, 105502] 1                                                                                                                                                                     
BHHO-INET-RTR1 @  192.168.23.42 [104726, 104677, 104675, 100102, 105484, 105506] 5                                                                                                                                
LinuxServer @ qbibsweb1 [105484, 105502] 1                                                                                                                                                                        
IBMAIXServer @ pbibsweb1 [105484, 105504] 3                                                                                                                                                                       
PostFixMailTransferAgent @ pbibsora1 [105484, 105505] 4                                                                                                                                                           
LinuxServer @ qbbankora2 [105484, 105502] 1                                                                                                                                                                       
LinuxServer @ qbbankora1 [105484, 105502] 1                                                                                                                                                                       
Jump Server: JO-Helpdesk @ SRVBMNMJMPHDK - 10.11.11.9 [105497, 104675, 104729, 105484, 104677, 105504] 3                                                                                                          
F5ASM @ HBTFLTMEXT01.bahrain.housingbank.local [104677, 104727, 104675, 105505] 4                                                                                                                                 
PostFixMailTransferAgent @ pbbankapp2 [105484, 105504] 3                                                                                                                                                          
F5APM @ HBTFLTMEXT01.bahrain.housingbank.local [104727, 104675, 104677, 105505] 4                                                                                                                                 
IBMAIXServer @ HBTFLTMEXT01.bahrain.housingbank.local [105505] 4                                                                                                                                                  
OracleDbAudit @ qbbankora1 [105484, 105502] 1                                                                                                                                                                     
BHHO-PA-UNTSTSW1 @ 10.11.18.19 [104677, 105484, 104675, 104726, 105506] 5                                                                                                                                         
IBMAIXServer @ HBTFLTMEXT02.bahrain.housingbank.local  [104675, 104677, 105484, 104727, 105504] 3                                                                                                                 
PBBANKAPP1 @ 172.29.13.40 [104733, 104677, 105484, 104675, 105504] 3                                                                                                                                              
Open Banking: GW @ BHMNMOBGWPROD - 10.30.32.4 [104675, 105484, 104677, 104728, 105497, 105506] 5  
                                                                                                                
Sendmail @ pbbankora1 [105484, 105505] 4                                                                                                                                                                          
LinuxServer @ qbbankapp2 [105484, 105502] 1                                                                                                                                                                       
Sendmail @ pbibsora1 [105484, 105505] 4                                                                                                                                                                           
BHHO-FTD-DMZSW1 @ 10.11.18.18 [104677, 105484, 104675, 104726, 105506] 5                                                                                                                                          
PBBANKORA1 @ 172.29.13.2  [104675, 104677, 104734, 105484, 105505] 4                                                                                                                                              
LinuxServer @ qbibsora1 [105484, 105502] 1                                                                                                                                                                        
LinuxServer @ HBTFLTMEXT02.bahrain.housingbank.local [104675, 104727, 104677, 105504] 3                                                                                                                           
PostFixMailTransferAgent @ pbbankapp1 [105484, 105504] 3                                                                                                                                                          
LinuxServer @ qbibsapp1 [105484, 105502] 1                                                                                                                                                                        
LinuxServer @ HBTFLTMEXT01.bahrain.housingbank.local [104677, 104727, 104675, 105505] 4                                                                                                                           
PBBANKORA1 @ 172.29.13.2 [105484, 104734, 104675, 104677, 105505] 4                                                                                                                                               
LinuxServer @ qbbankapp1 [105484, 105502] 1
IBMAIXServer @ pbbankapp1 [105484, 105504] 3                                                                                                                                                                      
IBMAIXServer @ HBTFLTMEXT01.bahrain.housingbank.local [104677, 104727, 104675, 105505] 4                                                                                                                          
Forcepoint V Series @ HBTFLTMEXT01.bahrain.housingbank.local [104677, 104675, 104727, 105505] 4                                                                                                                   
PostFixMailTransferAgent @ pbbankora1 [105484, 105505] 4                                                                                                                                                          
PostFixMailTransferAgent @ pbibsora2 [105484, 105505] 4                                                                                                                                                           
PostFixMailTransferAgent @ pbbankora2 [105484, 105505] 4                                                                                                                                                          
root@seclog:/home# vi Generic_Logs_undifined_Log_Sources_v4.py                                                                                                                                                    
root@seclog:/home# python3 Generic_Logs_undifined_Log_Sources_v4.py                                                                                                                                               
OracleDbAudit @ qbibsora1 [105484, 105502] 1                                                                                                                                                                      
BHHO-PA-CSW01 @ 10.11.18.2 [105484, 104677, 104675, 104726, 105505] 4                                                                                                                                             
F5ASM @ HBTFLTMEXT02.bahrain.housingbank.local [104675, 104727, 104677, 105504] 3                                                                                                                                 
F5APM @ pbbankapp1 [105484, 105504] 3                                                                                                                                                                             
BHHO-SINAND-RTR @ 192.168.28.3 [104675, 104726, 105484, 104677, 105506] 5                                                                                                                                         
PostFixMailTransferAgent @ qbbankora1 [105484, 105502] 1                                                                                                                                                          
PostFixMailTransferAgent @ qbibsweb1 [105484, 105502] 1                                                                                                                                                           
IBMAIXServer @ HBTFLTMEXT02.bahrain.housingbank.local [104727, 104675, 105484, 104677, 105504] 3                                                                                                                  
Forcepoint V Series @ HBTFLTMEXT02.bahrain.housingbank.local [104675, 104727, 104677, 105504] 3                                                                                                                   
PostFixMailTransferAgent @ qbibsapp1 [105484, 105502] 1                                                                                                                                                           
BHHO-FTD-INETSW1 @ 10.11.18.20 [104726, 104677, 104675, 105484, 105506] 5                                                                                                                                         
BHHO-FTD-INETSW1 @ 10.11.18.20 [104726, 104677, 104675, 105484, 105505] 4                                                                                                                                         
BHHO-SER-SW02 @ 10.11.18.22 [104675, 105484, 104677, 104726, 105505] 4                                                                                                                                            
BHHO-PADMZ-SW2 @ 10.11.18.16 [104677, 104675, 100099, 104726, 105503] 2                                                                                                                                           
F5LTM @ HBTFLTMEXT02.bahrain.housingbank.local [105484, 104675, 104677, 104727, 105504] 3                                                                                                                         
IBMAIXServer @ pbibsapp1 [105484, 105504] 3                                                                                                                                                                       
VmWare @ HBTFLTMEXT01.bahrain.housingbank.local [104677, 104675, 104727, 105505] 4                                                                                                                                
BHHO-SER-SW01 @ 10.11.18.21 [105484, 104726, 104675, 104677, 105505] 4 
'''

import requests                                                                                                                                                                                                   
import urllib3                                                                                                                                                                                                    
import json                                                                                                                                                                                                       
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)                                                                                                                                               
headers = {"Accept": "application/json", "SEC":"d1ac2d48-531d-4cc1-b56e-583330db9227" , "Version":"22.0"}                                                                                                         
url = "https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources"                                                                                                             
response= requests.get(url , headers=headers,verify=False)                                                                                                                                                        
dict={'1':105502, '2':105503, '3':105504, '4':105505, '5':105506}                                                                                                                                                 
l = open('Bahrain_Asset.csv' , 'r').read().split('\n')[:-1]                                                                                                                                                       
for logsource in response.json():                                                                                                                                                                                 
    for server in l :                                                                                                                                                                                             
        if ( ' '.join(server.split(',')[:-2]).lower().strip(' ') in logsource['name'].lower().strip(' ') or ' '.join(server.split(',')[-2]).lower().strip(' ') in logsource['name'].lower().strip(' ')) and server
.split(',')[0]!=' ' :                                                                                                                                                                                             
            group_ids = logsource['group_ids']                                                                                                                                                                    
            if 0 in group_ids:                                                                                                                                                                                    
                group_ids.remove(0)                                                                                                                                                                               
            group_ids = group_ids+[dict[server.split(',')[-1]]]                                                                                                                                                   
            print(logsource['name'] , group_ids , server.split(',')[-1] )                                                                                                                                         
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  
            requests.post(f"{url}/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids  } ,verify=False)                                                                                           
#            print(logsource['name'] , server.split(',')[-1]) 