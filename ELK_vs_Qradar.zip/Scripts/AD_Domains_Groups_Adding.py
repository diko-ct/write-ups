import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
                        
                        
headers = {"Accept": "application/json", "SEC":"d1ac2d48-531d-4cc1-b56e-583330db9227" , "Version":"22.0"}
                        
                        
url = "https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources"   
                        
                        
response= requests.get(url , headers=headers,verify=False)         
           
                        
                        
#syslog msrpc wincollect
#{0, 59, 39}            
"""                     
for logsource in response.json():                                  
    if logsource["type_id"] == 12 :                 
        if logsource["protocol_type_id"] in (39 , 59):             
            for parameter in logsource["protocol_parameters"]:     
                if 'domain' in parameter['name'].lower():          
                    domains.append(parameter['value'])             
                        
print(set(domains))     
"""                     


for logsource in response.json(): 
# type id 12 means log source type equals windows                                     
    if logsource["type_id"] == 12 :              
# protocol id 39 = wincollect, 59 = msrcp , 0 = syslog                  
        if logsource["protocol_type_id"] in  (39 , 59):       
# trying to find domain parameter             
            for parameter in logsource["protocol_parameters"]:     
                if 'Login_Domain'.lower() in parameter['name'].lower() or 'DomainName' in parameter['name'].lower():
# remove 0 group which is other. (it's removed because it will cause an error when adding another group)
                    group_ids.remove(0)                       
# categorise Log sources based on Domain          
                    if 'jordan' in parameter['value'].lower(): 
# Adding domain group    
                        group_ids = logsource['group_ids'] +[105495]
# edit log source
                        r = requests.post(f"https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)    
                    elif 'swift' in parameter['value'].lower():    
                        group_ids = logsource['group_ids'] +[105498]
                        r = requests.post(f"https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)   
                    elif 'bahrain' in parameter['value'].lower() or 'hbtf-bh' in parameter['value'].lower():
                        group_ids = logsource['group_ids'] +[105497]
                        r = requests.post(f"https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)   
                    elif 'palestine' in parameter['value'].lower():
                        group_ids = logsource['group_ids'] +[105496]
                        r = requests.post(f"https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)   
                    elif 'hbk.com.jo' in parameter['value'].lower():
                        group_ids = logsource['group_ids'] +[105500]
                        r = requests.post(f"https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)   
                    elif 'dhousingbank.corp' in parameter['value'].lower() and 0 in logsource['group_ids']:           
                        group_ids = logsource['group_ids'] +[105500]
                        r = requests.post(f"https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids } ,verify=False)
