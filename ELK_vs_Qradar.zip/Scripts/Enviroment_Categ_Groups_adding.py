import requests               
import urllib3                
import json 
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
headers = {"Accept": "application/json", "SEC":"d1ac2d48-531d-4cc1-b56e-583330db9227" , "Version":"22.0"}
url = "https://qradar-console.hbtf.com.jo/api/config/event_sources/log_source_management/log_sources" 
response= requests.get(url , headers=headers,verify=False)
l = open('Assets.csv' , 'r').read().split('\n') 
dic1 = {"HA":105525,"PROD":105486,"TEST":105487,"DR":105489,"DMZ DR":105489 , "SHM":105486,"HQ":105486, "QA":105487, "UAT":105487,"DC":105486,"DEV":105487 , "MAIN":105486 }  
            
for logsource in response.json():
    for server in l :
            
        if ( ' '.join(server.split(',')[:-2]).lower().strip(' ') in  logsource['name'].lower().strip(' ') or ' '.join(server.split(',')[-2]).lower().strip(' ') ==  logsource['name'].lower().strip(' ')) and not 
( server.split(',')[:-2]==' '   or len(' '.join(server.split(',')[:-2]).lower().strip(' ')) < 5       ) :               
            group_ids = logsource['group_ids']  
            if 0 in group_ids:
                group_ids.remove(0)             
            group_ids = group_ids+[dic1[server.split(',')[-1].upper()]]             
            print(logsource['name'] , server.split(',')[-1].upper())                
            requests.post(f"{url}/{logsource['id']}" , headers=headers, json={"group_ids" : group_ids  } ,verify=False) 
            break