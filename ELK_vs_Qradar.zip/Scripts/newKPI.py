
import re
from pyotrs import Client
import os
import ssl
import time
import datetime
import requests
import openpyxl
import datetime
import schedule 
# --------------
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# --------------


def fetch_AQL_result(AQL):
    print('-'*50)
    base_url = "https://10.1.244.77:443/api/ariel/searches"
    headers = {
        "Accept": "application/json",
        "SEC": "dd30cb08-7374-49e2-b5bc-3079310e9232",
        "Version": "9.0"
    }

    response = requests.post(url=f'{base_url}?query_expression={AQL}', headers=headers, verify=False)

    if response.status_code == 201:
        print(f'[+] Query Submitted: {AQL}')
        search_id = response.json()["search_id"]
        print("[+] Search ID: ", search_id)

        # Wait for the search to complete
        print(f'[*] Waiting for search to complete...')
        seach_start = time.time()
        while True:
            response = requests.get(url=f'{base_url}/{search_id}', headers=headers, verify=False)
            if response.status_code == 200:
                search_status = response.json()["status"]
                if search_status == "COMPLETED":
                    break
            print(f"Elapsed time: {time.time() - seach_start:.2f} seconds", end="\r")
            time.sleep(1)
        print(f'[+] Search completed. Total time: {time.time() - seach_start:.2f}')
    else:
        print(f'[-] ERROR occured while submitting the search request.')
        print(response.status_code, response.text)
        exit(-1)

    # Fetch the results of the AQL query
    print('[*] Downloading results.')
    download_start = time.time()
    response = requests.get(url=f'{base_url}/{search_id}/results', headers=headers, verify=False)
    
    if response.status_code == 200:
        print(f'[+] Download completed. Total time: {time.time() - download_start:.2f}')
        results = response.json()["events"]
        print(f'[+] {len(results)} events returned.')
        if len(results) < 0: exit(0)
        else: return results
    else:
        print("[-] Failed to Download results.")
        print(response.status_code, response.text)
        exit(-1)
###################################################################################################
def Our_Own_Use_Cases():

    base_url = 'https://10.1.244.77/api/siem/offenses/'
    headers = {
        "Accept": "application/json",
        "SEC": "dd30cb08-7374-49e2-b5bc-3079310e9232",
        "Version": "9.0"
    }
    



    end_date = datetime.datetime.now()
    start_date = end_date - datetime.timedelta(days=6)
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')
    time=end_date.strftime('%Y%m%d')
    Closed  = fetch_AQL_result(f'''  select  "Offense ID", "Offense Closed Reason" , DATEFORMAT(starttime,'YYYY-MM-dd hh:mm') AS "TIME"    from events where qid=28250021  START '{start_date_str} 00:00:00'  STOP '{end_date_str} 23:59:59'  ''')

    temp = [ ]

    for offense in Closed: 
        if offense['Offense Closed Reason'] != 'Use Case Under Development':
            temp.append(offense)
            
    close=temp



    ClosedOffenses = [ offense['Offense ID'] for offense in Closed ]
    avg = []
    for offense in ClosedOffenses: 
        try: 
            response = requests.post(url=f'{base_url}{offense}', headers=headers, verify=False)
            
            avg.append(abs(datetime.datetime.strptime(Closed[ClosedOffenses.index(offense)]['TIME'] , '%Y-%m-%d %I:%M')  - datetime.datetime.fromtimestamp(response.json()['start_time']//1000) ).total_seconds())
        except:
            pass
    avgnumber = sum(avg) / len(avg) / 60/60/24

    print('- '*50)

    try:
        file_path = r"\\10.1.112.164\nisops\Shared\SOC KPI\Ops_KPI.xlsx"
        #file_path = r"C:\Users\ext.abdelrahman.dikn\Documents\Ops_KPI.xlsx"
        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook['ofs_KPI']
        
        current_row = 1 
        
        while sheet.cell(row=current_row, column=1).value is not None: current_row += 1
        sheet.cell(row=current_row, column=1, value=f"{start_date.year}")
        sheet.cell(row=current_row, column=3, value=f"{start_date.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}")
        sheet.cell(row=current_row, column=4, value="{:.1f}".format(avgnumber))

        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 
        filw.write(filr)
        filw.close()
        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {start_date.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50)
 


    


###################################################################################################

def Opened_Tickets():
    base_url = 'https://10.1.244.77/api/siem/offenses'
    headers = {
        "Accept": "application/json",
        "SEC": "dd30cb08-7374-49e2-b5bc-3079310e9232",
        "Version": "9.0",
        "Range":"items=0-"
    }
    Opened_Offenses = []

    response = requests.get(url=base_url, headers=headers, verify=False)
    for offense in response.json():
        try:

            if offense['status'] == "OPEN" and  abs( datetime.datetime.fromtimestamp(offense['start_time']//1000)  - datetime.datetime.now() ).total_seconds() >=604800:
                Opened_Offenses.append( [ offense['id'] ,  abs( datetime.datetime.fromtimestamp(offense['start_time']//1000)  - datetime.datetime.now() )])
        except : 
            pass
    
    try:
        file_path = r"\\10.1.112.164\nisops\Shared\SOC KPI\Ops_KPI.xlsx"
        #file_path = r"C:\Users\ext.abdelrahman.dikn\Documents\Ops_KPI.xlsx"
        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        time=datetime.datetime.now().strftime('%Y%m%d')
        


        sheet = workbook['Open_Tickets']
        
        current_row = 2
        while sheet.cell(row=current_row, column=2).value is not None: 
            sheet.cell(row=current_row, column=1, value="")
            sheet.cell(row=current_row, column=2, value="")
            current_row += 1

        


        current_row = 2 
        for Offense in Opened_Offenses : 
            sheet.cell(row=current_row, column=1, value=f"{Offense[0]}")
            sheet.cell(row=current_row, column=2, value=f"{Offense[1]}")
            current_row+=1

        
        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 
        filw.write(filr)
        filw.close()


        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {time}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50)


###################################################################################################


def Incidents_volume():
    end_date = datetime.datetime.now().replace(hour=23, minute=59, second=59, microsecond=0)
    
    time=end_date.strftime('%Y%m%d')
    first_of_month = end_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    Closed  = fetch_AQL_result(f''' select  "Offense ID", "Offense Closed Reason"   from events where qid=28250021 START '{first_of_month}'  STOP '{end_date}'   ''')

    events =[]
    incidents = [] 
    for Offense in Closed: 
        if Offense['Offense Closed Reason'] == 'Use Case Under Development':
            continue 
        
        if Offense['Offense Closed Reason'] == 'Incident' : 
            incidents.append(Offense['Offense Closed Reason'] )
            
        events.append(Offense['Offense Closed Reason'] )
    try:
        file_path = r"\\10.1.112.164\nisops\Shared\SOC KPI\Ops_KPI.xlsx"
        #file_path = r"C:\Users\ext.abdelrahman.dikn\Documents\Ops_KPI.xlsx"
        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook['Incidents_Volume']
        
        current_row = 1 
        
        while sheet.cell(row=current_row, column=3).value is not None: current_row += 1
        sheet.cell(row=current_row, column=1, value=f"{first_of_month.year}")

        
        sheet.cell(row=current_row, column=3, value=f"{first_of_month.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}")
        sheet.cell(row=current_row, column=5, value=f"{len(events)}")
        sheet.cell(row=current_row, column=7, value=f"{len(incidents)}")

        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 

        filw.write(filr)
        filw.close()
        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {first_of_month.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50)
                

    
    

###################################################################################################



def OTRS_Delay_Weekly():
    s = Client("https://10.1.166.185:8088", "Service", "Service@123")
    s.https_verify = False
    s.session_restore_or_create()
    week = (datetime.datetime.now() - datetime.timedelta(days=6)).replace(hour=0, minute=0, second=0, microsecond=0)
    tickets = s.ticket_search(TicketCreateTimeNewerDate=week)
    pattern = re.compile(r'(\d{7,})')
    CreatedOTRS=[]
    Creation={}
    for i in tickets:
        
        search_match = pattern.search(s.ticket_get_by_id(i).to_dct()['Ticket']['Title'] )
        if search_match:
            CreatedOTRS.append(search_match.group().strip())
            Creation[search_match.group().strip()]=s.ticket_get_by_id(i).to_dct()['Ticket']['Created']
    
    

    

    end_date = datetime.datetime.now()
    start_date1 = week
    start_date = end_date - datetime.timedelta(days=30)

    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')
    time=end_date.strftime('%Y%m%d')
    
    
    Created = fetch_AQL_result(f''' select  "Offense ID", "Rule ID", DATEFORMAT(starttime,'YYYY-MM-dd hh:mm')  AS "TIME"   from events where qid=28250369  START '{start_date_str} 00:00:00'  STOP '{end_date_str} 23:59:59'      ''')
    CreatedOffenses = [ offense['Offense ID'] for offense in Created ]

    Found = [  otrs  for otrs  in CreatedOTRS if otrs in CreatedOffenses]
    avg = [] 
    final_list = [] 

    for offense in Found:
        final_list.append([ offense ,  datetime.datetime.strptime( Created[CreatedOffenses.index(offense)]['TIME'], "%Y-%m-%d %H:%M" ) , datetime.datetime.strptime(Creation[offense] , "%Y-%m-%d %H:%M:%S" )  , abs(datetime.datetime.strptime( Created[CreatedOffenses.index(offense)]['TIME'], "%Y-%m-%d %H:%M" ) - datetime.datetime.strptime(Creation[offense] , "%Y-%m-%d %H:%M:%S" ) )  ] )
        avg.append( abs(datetime.datetime.strptime( Created[CreatedOffenses.index(offense)]['TIME'], "%Y-%m-%d %H:%M" ) - datetime.datetime.strptime(Creation[offense] , "%Y-%m-%d %H:%M:%S" ) ).total_seconds())
    avgnumber = sum(avg) / len(avg ) / 60/ 60 /24 



    try:
        file_path = r"\\10.1.112.164\nisops\Shared\SOC KPI\Ops_KPI.xlsx"
        #file_path = r"C:\Users\ext.abdelrahman.dikn\Documents\Ops_KPI.xlsx"
        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook['OTRS Delay']
        
        current_row = 1 
        
        while sheet.cell(row=current_row, column=1).value is not None: current_row += 1
        sheet.cell(row=current_row, column=1, value=f"{start_date1.year}")
        sheet.cell(row=current_row, column=3, value=f"{start_date1.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}")
        sheet.cell(row=current_row, column=4, value="{:.1f}".format(avgnumber))


        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 
        filw.write(filr)
        filw.close()
        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {start_date1.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50) 




###################################################################################################


def Tuning(): 
    end_date = datetime.datetime.now().replace( hour=23, minute=55, second=50, microsecond=0)
    
    time=end_date.strftime('%Y%m%d')
    first_of_month = end_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    Closed  = fetch_AQL_result(f''' select  "Offense ID", "Offense Closed Reason"   from events where qid=28250021 START '{first_of_month}'  STOP '{end_date}'    ''')
    FPNT = 0 
    FPT = 0 

    for Offense in Closed : 

        
        if Offense["Offense Closed Reason"] == "False Positive, Not Tuned" : 
            FPNT +=1 
        elif Offense["Offense Closed Reason"] == "False-Positive, Tuned" : 
            FPT +=1 
    try:
        file_path = r"\\10.1.112.164\nisops\Shared\SOC KPI\Ops_KPI.xlsx"
        #file_path = r"C:\Users\ext.abdelrahman.dikn\Documents\Ops_KPI.xlsx"
        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook['Tuning']
        
        current_row = 1 
        
        while sheet.cell(row=current_row, column=3).value is not None: current_row += 1
        sheet.cell(row=current_row, column=1, value=f"{first_of_month.year}")
        sheet.cell(row=current_row, column=3, value=f"{first_of_month.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}")
        sheet.cell(row=current_row, column=4, value=f"{FPT}")
        sheet.cell(row=current_row, column=5, value=f"{FPNT}")


        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 
        filw.write(filr)
        filw.close()
        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {first_of_month.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50)




###################################################################################################

def raw_data(): 
    base_url = 'https://10.1.244.77/api/siem/offenses/'
    headers = {
        "Accept": "application/json",
        "SEC": "dd30cb08-7374-49e2-b5bc-3079310e9232",
        "Version": "9.0"
    }
    s = Client("https://10.1.166.185:8088", "Service", "Service@123")
    s.https_verify = False
    s.session_restore_or_create()
    week = (datetime.datetime.now() - datetime.timedelta(days=6)).replace(hour=0, minute=0, second=0, microsecond=0)
    tickets = s.ticket_search(TicketCreateTimeNewerDate=week)
    pattern = re.compile(r'(\d{7,})')
    CreatedOTRS=[]
    Creation={}
    for i in tickets:
        
        search_match = pattern.search(s.ticket_get_by_id(i).to_dct()['Ticket']['Title'] )
        if search_match:
            CreatedOTRS.append(search_match.group().strip())
            Creation[search_match.group().strip()]=s.ticket_get_by_id(i).to_dct()['Ticket']['Created']


    end_date = datetime.datetime.now()
    start_date = end_date - datetime.timedelta(days=6)
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')
    time=end_date.strftime('%Y%m%d')
    Closed  = fetch_AQL_result(f''' select  "Offense ID", DATEFORMAT(starttime,'YYYY-MM-dd hh:mm') AS "TIME"    from events where qid=28250021  START '{start_date_str} 00:00:00'  STOP '{end_date_str} 23:59:59'  ''')
    
    
    ClosedOffenses = [ offense['Offense ID'] for offense in Closed ]
    ClosedInTime =[]

    for closed in  range(len(ClosedOffenses)) : 
        try: 
            response = requests.post(url=f'{base_url}{ClosedOffenses[closed ]}', headers=headers, verify=False)
            ClosedInTime.append([ClosedOffenses[closed ] , datetime.datetime.strptime(Closed[closed]['TIME'] , '%Y-%m-%d %I:%M') ,  datetime.datetime.fromtimestamp(response.json()['start_time']//1000) ]) 
        except : 
            pass        

        
    Deff = [] 
    for offense in ClosedInTime: 
        try: 
            if offense[0] in CreatedOTRS: 
                Deff.append(offense + [datetime.datetime.strptime(Creation[offense[0]] , "%Y-%m-%d %H:%M:%S")   , abs(datetime.datetime.strptime(Creation[offense[0]] , "%Y-%m-%d %H:%M:%S") - offense[2]) ] )
            else : 
                Deff.append(offense  )
        except : 
            pass
    try:
        file_path = r"\\10.1.112.164\nisops\shared\SOC KPI\Ops_KPI.xlsx"
        #file_path = r"C:\Users\ext.abdelrahman.dikn\Documents\Ops_KPI.xlsx"
        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook['Raw_Sheet']
        
        current_row = 1 
        
        while sheet.cell(row=current_row, column=1).value is not None: current_row += 1

        for offense in Deff: 
            if len(offense) == 5 : 

                sheet.cell(row=current_row, column=1, value=f"{offense[0]}")
                sheet.cell(row=current_row, column=2, value=f"{offense[2].strftime('%Y.%m.%d %H:%M')}")
                sheet.cell(row=current_row, column=3, value=f"{offense[1].strftime('%Y.%m.%d %H:%M')}")
                sheet.cell(row=current_row, column=4, value=f"{offense[3].strftime('%Y.%m.%d %H:%M')}")
                sheet.cell(row=current_row, column=5, value=f"{offense[4]}")
            else  : 
                sheet.cell(row=current_row, column=1, value=f"{offense[0]}")
                sheet.cell(row=current_row, column=2, value=f"{offense[2].strftime('%Y.%m.%d %H:%M')}")
                sheet.cell(row=current_row, column=3, value=f"{offense[1].strftime('%Y.%m.%d %H:%M')}")

            current_row+=1


        
        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 
        
        filw.write(filr)
        
        filw.close()
       
        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {start_date.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50)




def FalsePositivesWeekly():
    end_date = datetime.datetime.now().replace( hour=23, minute=55, second=50, microsecond=0)
    

    time=datetime.datetime.now().strftime('%Y%m%d')
    start_date =end_date - datetime.timedelta(days=6)
    Closed  = fetch_AQL_result(f''' select  "Offense ID", "Offense Closed Reason"   from events where qid=28250021 START '{start_date}'  STOP '{end_date}'    ''')
    

    Events = 0 
    Fls = 0 

    for offense in Closed: 
        try: 
            if offense['Offense Closed Reason']  =='Use Case Under Development':
                continue
            if 'False Positive' in offense['Offense Closed Reason']: 
                Fls +=1 
            else : 
                Events +=1 
        except : 
            pass

    try:
        file_path = r"\\10.1.112.164\nisops\Shared\SOC KPI\Ops_KPI.xlsx"
        #file_path = r"C:\Users\ext.abdelrahman.dikn\Documents\Ops_KPI.xlsx"

        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook['False Positives Weekly']
        
        current_row = 1 
        
        while sheet.cell(row=current_row, column=3).value is not None: current_row += 1
        sheet.cell(row=current_row, column=1, value=f"{start_date.year }")
        sheet.cell(row=current_row, column=3, value=f"{start_date.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}")
        sheet.cell(row=current_row, column=5, value=f"{Events}")
        sheet.cell(row=current_row, column=7, value=f"{Fls}")
        sheet.cell(row=current_row, column=8, value=f"{Fls/Events:.2f}")

        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 

        filw.write(filr)
        filw.close()
        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {start_date.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50)
    

def FalsePositivesMonthly():
    end_date = datetime.datetime.now().replace( hour=23, minute=55, second=50, microsecond=0)
    

    time=datetime.datetime.now().strftime('%Y%m%d')
    start_date =end_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    Closed  = fetch_AQL_result(f''' select  "Offense ID", "Offense Closed Reason"   from events where qid=28250021 START '{start_date}'  STOP '{end_date}'    ''')
    

    Events = 0 
    Fls = 0 

    for offense in Closed: 
        if offense['Offense Closed Reason'] is not None :  

            if offense['Offense Closed Reason']  =='Use Case Under Development':
                continue
            

            if 'False Positive' in offense['Offense Closed Reason']: 
                Fls +=1 
            else : 
                Events +=1
        else : 
            Events+=1


    
    try:
        file_path = r"\\10.1.112.164\nisops\Shared\SOC KPI\Ops_KPI.xlsx"
        print(f'[*] Writing data to the KPI excell sheet at "{file_path}"')
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook['False Positives Monthly']
        
        current_row = 1 
        
        while sheet.cell(row=current_row, column=3).value is not None: current_row += 1
        
        sheet.cell(row=current_row, column=1, value=f"{start_date.year }")
        sheet.cell(row=current_row, column=3, value=f"{start_date.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}")
        sheet.cell(row=current_row, column=5, value=f"{Events}")
        sheet.cell(row=current_row, column=7, value=f"{Fls}")
        sheet.cell(row=current_row, column=8, value=f"{Fls/Events}")

        workbook.save(file_path)
        filr = open(file_path , 'br').read()
        filw = open(file_path[:-5 ] +time + '.xlsx' , 'wb') 

        filw.write(filr)
        filw.close()
        print(f'[+] Data was successfully written to the KPI excell sheet at "{file_path}"')
        print(f"[+] Weekly report for {start_date.strftime('%Y.%m.%d')}-{end_date.strftime('%Y.%m.%d')}  has been completed.]")
    except:
        print('[-] Unknown error occured while writing to the KPI excell sheet...')
    print('- '*50)



def generate_daily_reports():
    pass
    
        
def generate_weekly_reports():
    Our_Own_Use_Cases()
    Opened_Tickets()
    OTRS_Delay_Weekly()
    raw_data()
    FalsePositivesWeekly()
    print("!!!Attention!!!\n Please let it run peacefully")
    return 


def generate_monthly_reports():
    
    if datetime.date.today().month != (datetime.date.today()+ datetime.timedelta(days=1)).month :
     
        Incidents_volume()
        Tuning()
        FalsePositivesMonthly()
        Opened_Tickets()
    print("!!!Attention!!!\n Please let it run peacefully ")
    return 
        



    return 
def main():
    print("!!!Attention!!!\n Please let it run peacefully")
    schedule.every().day.at("23:30").do(generate_monthly_reports)
    schedule.every().sunday.at("23:30").do(generate_weekly_reports)
    
    while True:
        schedule.run_pending()
        time.sleep(1)
    
    





    
    return
if __name__ == "__main__" : 
    main()


