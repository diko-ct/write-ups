const translations = {"welcomeTitle":"IBM QRadar Use Case Manager Rules Export","welcomeLabelName":"Export name:","welcomeLabelTime":"Export time:","welcomeLabelVersion":"UCM version:","welcomeMessage":"Select a rule from the list to see more details.","ruleListTitle":"Investigate rules","ruleListSearchPlaceholder":"Start typing to filter list.","ruleListShowDepsTooltip":"Show dependents and dependencies in list.","ruleListHideDepsTooltip":"Show only rules that were selected for export.","detailsEnabled":"Enabled","detailsDisabled":"Disabled","detailsNotes":"Notes","detailsTestDef":"Test definitions","detailsMitreAttack":"MITRE ATT&CK®","detailsMitreTagView":"Tag view","detailsMitreTileView":"Tile view","detailsMitreTactic":"Tactic:","detailsMitreTech":"Techniques used:","detailsMitreConfidenceLabel":"Confidence:","detailsMitreMapSource":"Mapping source:","detailsMitreConfidence":"Confidence","detailsGroups":"Groups","detailsRuleAction":"Rule action","detailsRuleResponse":"Rule response","detailsRuleLimiter":"Rule limiter","detailsRuleLimiterText":"Respond no more than {0} time(s) per {1} {2} per {3}","detailsRuleLimiterSeconds":"second(s)","detailsRuleLimiterMinutes":"minute(s)","detailsRuleLimiterHours":"hour(s)","detailsDetails":"Rule details","detailsDetailsType":"Type:","detailsDetailsOwner":"Owner:","detailsDateUpdated":"Date updated:","detailsDetailsOrigin":"Origin:","detailsDetailsDateCreated":"Date created:","detailsDetailsCategory":"Category:","detailsDetailsRuleId":"Rule ID:","detailsDetailsRuleUuid":"Rule UUID:","detailsCustomAttributes":"Custom attributes","detailsUBARisk":"User Behavior Analytics risk score","detailsUBARiskDesc":"Risk score used by QRadar User Behavior Analytics app.","detailsDependencies":"Dependencies","detailsDependents":"Dependents","detailsLST":"Log Source Types","detailsNotFound":"No results found","dependencyTree":"Dependency Tree"};
 let tooltip;
let elmEdges;
let tooltipHTML;
let elmTop;
let showDeps = false;
const rulesObj = rules;
let selectedRuleId = null;
let showMitreTileView = false;
const dateOptions = {
  month: "long",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "numeric"
};

const setStaticStrings = () => {
  document.getElementById("welcome-screen__title").innerText =
    translations.welcomeTitle;
  document.getElementById("welcome-screen__export-name--label").innerText =
    translations.welcomeLabelName;
  document.getElementById("welcome-screen__export-time--label").innerText =
    translations.welcomeLabelTime;
  document.getElementById("welcome-screen__export-version--label").innerText =
    translations.welcomeLabelVersion;
  document.getElementById("welcome-screen__message").innerText =
    translations.welcomeMessage;
  document.getElementById("ucm-info__export-name--label").innerText =
    translations.welcomeLabelName;
  document.getElementById("ucm-info__export-time--label").innerText =
    translations.welcomeLabelTime;
  document.getElementById("ucm-info__export-version--label").innerText =
    translations.welcomeLabelVersion;
  document.getElementById("left-panel__title").innerText =
    translations.ruleListTitle;
  document
    .getElementById("search-bar__input")
    .setAttribute("placeholder", translations.ruleListSearchPlaceholder);
  document
    .getElementById("search-bar__dep-button")
    .setAttribute("datatooltip", translations.ruleListShowDepsTooltip);
  document.getElementById("notes__header").innerText =
    translations.detailsNotes;
  document.getElementById("test-def__header").innerText =
    translations.detailsTestDef;
  document.getElementById("mitre-section__header").innerText =
    translations.detailsMitreAttack;
  document.getElementById("mitre-section__tag-btn-label").innerText =
    translations.detailsMitreTagView;
  document.getElementById("mitre-section__tile-btn-label").innerText =
    translations.detailsMitreTileView;
  document.getElementById("groups__header").innerText =
    translations.detailsGroups;
  document.getElementById("rule-action__header").innerText =
    translations.detailsRuleAction;
  document.getElementById("rule-response__header").innerText =
    translations.detailsRuleResponse;
  document.getElementById("rule-limiter__header").innerText =
    translations.detailsRuleLimiter;
  document.getElementById("rule-details__header").innerText =
    translations.detailsDetails;
  document.getElementById("type__th").innerText =
    translations.detailsDetailsType;
  document.getElementById("owner__th").innerText =
    translations.detailsDetailsOwner;
  document.getElementById("updated__th").innerText =
    translations.detailsDateUpdated;
  document.getElementById("origin__th").innerText =
    translations.detailsDetailsOrigin;
  document.getElementById("created__th").innerText =
    translations.detailsDetailsDateCreated;
  document.getElementById("category__th").innerText =
    translations.detailsDetailsCategory;
  document.getElementById("id__th").innerText =
    translations.detailsDetailsRuleId;
  document.getElementById("uuid__th").innerText =
    translations.detailsDetailsRuleUuid;
  document.getElementById("custom-attributes__header").innerText =
    translations.detailsCustomAttributes;
  document.getElementById("uba-risk-score__header").innerText =
    translations.detailsUBARisk;
  document.getElementById("uba-risk-score__description").innerText =
    translations.detailsUBARiskDesc;
  document.getElementById("dependencies__header").innerText =
    translations.detailsDependencies;
  document.getElementById("dependents__header").innerText =
    translations.detailsDependents;
  document.getElementById("log-source-types__header").innerText =
    translations.detailsLST;
};

const filterRuleList = () => {
  const searchText = document
    .getElementById("search-bar__input")
    .value.toLowerCase();
  if (searchText) {
    document
      .getElementsByClassName("search-bar__clear-btn")[0]
      .classList.remove("search-bar__clear-btn--hidden");
  } else {
    document
      .getElementsByClassName("search-bar__clear-btn")[0]
      .classList.add("search-bar__clear-btn--hidden");
  }
  document.getElementById("rules-list").innerHTML = Object.keys(rulesObj)
    .filter(ruleUid => {
      return (
        !searchText ||
        JSON.stringify(rulesObj[ruleUid])
          .toLowerCase()
          .includes(searchText)
      );
    })
    .map(ruleUid => {
      if (
        (showDeps || rulesObj[ruleUid].isSelected) &&
        rulesObj[ruleUid].name
      ) {
        return `<li
            id=${ruleUid}
            onclick="openRule('${ruleUid}')"
            class="link"
          >
            ${rulesObj[ruleUid].name}
          </li>`;
      }
      return "";
    })
    .join("");
  const selectedRuleListItem = document.getElementById(selectedRuleId);
  selectedRuleListItem && selectedRuleListItem.classList.add("selected");
};

const clearSearch = () => {
  document.getElementById("search-bar__input").value = "";
  filterRuleList();
};

const toggleShowDeps = () => {
  showDeps = !showDeps;
  if (showDeps) {
    document.getElementById("no-deps-symbol").style.display = "none";
    document
      .getElementById("search-bar__dep-button")
      .setAttribute("datatooltip", translations.ruleListHideDepsTooltip);
  } else {
    document.getElementById("no-deps-symbol").style.display = "inline";
    document
      .getElementById("search-bar__dep-button")
      .setAttribute("datatooltip", translations.ruleListShowDepsTooltip);
  }
  filterRuleList();
};

const openRule = ruleUid => {
  let selectedRuleListItem = document.getElementById(selectedRuleId);
  selectedRuleListItem && selectedRuleListItem.classList.remove("selected");
  selectedRuleListItem = document.getElementById(ruleUid);
  selectedRuleListItem && selectedRuleListItem.classList.add("selected");
  const rule = rulesObj[ruleUid];
  selectedRuleId = ruleUid;

  // Show Rule details
  document.getElementById("welcome-screen").style.display = "none";
  document.getElementById("rule-details-screen").style.display = "block";

  // Title
  document.getElementById("rule-details-screen__title").textContent = rule.name;

  // Enabled/Disabled
  document.getElementById("is-enabled-header").textContent = rule.enabled
    ? translations.detailsEnabled
    : translations.detailsDisabled;

  // Notes
  document.getElementById("notes__desc").textContent = rule.notes
    ? rule.notes
    : translations.detailsNotFound;

  // Test definition
  document.getElementById("test-def__test-list").innerHTML = rule.TD
    ? JSON.parse(rule.TD)
        .map(test => {
          if (test.startsWith("APPLY")) {
            return `<p><span class="test-def__green-span">APPLY</span> ${test.slice(
              5
            )}</p>`;
          } else if (test.startsWith("AND NOT")) {
            return `<p><span class="test-def__green-span">AND NOT</span> ${test.slice(
              7
            )}</p>`;
          } else if (test.startsWith("AND")) {
            return `<p><span class="test-def__green-span">AND</span> ${test.slice(
              4
            )}</p>`;
          } else {
            return `<p>${test}</p>`;
          }
        })
        .join("")
    : `<p>${translations.detailsNotFound}</p>`;

  // Mitre
  if (Object.keys(rule.TAC).length) {
    document.getElementById("mitre-section__view-toggle").style.display =
      "inline-flex";
    if (showMitreTileView) {
      document.getElementById(
        "mitre-mappings__container"
      ).innerHTML = Object.keys(rule.TAC)
        .sort((firstElm, secondElm) => {
          if (rule.TAC[firstElm].length > rule.TAC[secondElm].length) {
            return 1;
          } else if (rule.TAC[firstElm].length < rule.TAC[secondElm].length) {
            return -1;
          } else {
            if (
              (rule.TAC[firstElm][0].TEC === "None" &&
                rule.TAC[secondElm][0].TEC === "None") ||
              (rule.TAC[firstElm][0].TEC !== "None" &&
                rule.TAC[secondElm][0].TEC !== "None")
            ) {
              if (rule.TAC[firstElm].some(item => item.MAP_C === "high")) {
                if (rule.TAC[secondElm].some(item => item.MAP_C === "high")) {
                  return 0;
                } else {
                  return -1;
                }
              } else if (
                rule.TAC[firstElm].some(item => item.MAP_C === "medium")
              ) {
                if (rule.TAC[secondElm].some(item => item.MAP_C === "high")) {
                  return 1;
                } else if (
                  rule.TAC[secondElm].some(item => item.MAP_C === "medium")
                ) {
                  return 0;
                } else {
                  return -1;
                }
              }
              if (rule.TAC[secondElm].every(item => item.MAP_C === "low")) {
                return 0;
              } else {
                return 1;
              }
            }
            if (rule.TAC[firstElm][0].TEC === "None") {
              return -1;
            } else {
              return 1;
            }
          }
        })
        .map(tacticName => {
          const tactic = rule.TAC[tacticName];
          const mapSource = tactic[0].MAP_S[0].values
            .map(s => {
              return s.bb;
            })
            .join(", ");
          if (tactic.length > 1 || tactic[0].TEC !== "None") {
            let confidence = "mitre-tile-low";
            if (tactic.some(item => item.MAP_C === "high")) {
              confidence = "mitre-tile-high";
            } else if (tactic.some(item => item.MAP_C === "medium")) {
              confidence = "mitre-tile-medium";
            }
            return `<div class="mitre-tile ${confidence}">
                        <div>
                            <span class='bold'>${
                              translations.detailsMitreTactic
                            }</span> ${tacticName}
                        </div>
                        <table class='mitre-tooltip__table'>
                            <tr>
                                <th>${translations.detailsMitreTech}</th>
                                <th>${
                                  translations.detailsMitreConfidenceLabel
                                }</th>
                                <th>${translations.detailsMitreMapSource}</th>
                            </tr>
                            ${tactic
                              .map(tec => {
                                return `<tr>
                                        <td><li>${tec.TEC}</li></td>
                                        <td>${tec.MAP_C.toUpperCase()} ${
                                  translations.detailsMitreConfidence
                                }
                                        </td>
                                        <td>
                                          <div class="mapping-source--large-tile">${mapSource}</div>
                                        </td>
                                        <td>
                                          ${
                                            tec.MAP_EN
                                              ? translations.detailsEnabled
                                              : translations.detailsDisabled
                                          }
                                        </td>
                                    </tr>`;
                              })
                              .join("")}
                            </table>
                        </div>`;
          } else {
            return `<div class="mitre-tile mitre-tile-${tactic[0].MAP_C}">
                <div class='mitre-tooltip__first-row'>
                    <div><span class='bold'>${
                      translations.detailsMitreTactic
                    }</span> ${tacticName}</div>
                    <div>${tactic[0].MAP_C.toUpperCase()} ${
              translations.detailsMitreConfidence
            }</div>
                    <div>${
                      tactic[0].MAP_EN
                        ? translations.detailsEnabled
                        : translations.detailsDisabled
                    }</div>
                </div>
                <div><span class='bold'>${
                  translations.detailsMitreMapSource
                }</span></div>
                <div class="mapping-source--small-tile">${mapSource}</div>
              </div>`;
          }
        })
        .join("");
    } else {
      document.getElementById(
        "mitre-mappings__container"
      ).innerHTML = Object.keys(rule.TAC)
        .sort((firstElm, secondElm) => {
          if (rule.TAC[firstElm].some(item => item.MAP_C === "high")) {
            if (rule.TAC[secondElm].some(item => item.MAP_C === "high")) {
              return 0;
            } else {
              return -1;
            }
          } else if (rule.TAC[firstElm].some(item => item.MAP_C === "medium")) {
            if (rule.TAC[secondElm].some(item => item.MAP_C === "high")) {
              return 1;
            } else if (
              rule.TAC[secondElm].some(item => item.MAP_C === "medium")
            ) {
              return 0;
            } else {
              return -1;
            }
          }
          if (rule.TAC[secondElm].some(item => item.MAP_C === "low")) {
            return 0;
          } else {
            return 1;
          }
        })
        .map(tacticName => {
          const tactic = rule.TAC[tacticName];
          const mapSource = tactic[0].MAP_S[0].values
            .map(s => {
              return s.bb;
            })
            .join(", ");
          if (tactic.length > 1 || tactic[0].TEC !== "None") {
            let confidence = "mitre-low";
            if (tactic.some(item => item.MAP_C === "high")) {
              confidence = "mitre-high";
            } else if (tactic.some(item => item.MAP_C === "medium")) {
              confidence = "mitre-medium";
            }
            const tooltipContent = `<div>
                <p><span class='bold'>${
                  translations.detailsMitreTactic
                }</span> ${tacticName}</p>
              </div>
              <table class='mitre-tooltip__table'>
                <tr>
                    <th>${translations.detailsMitreTech}</th>
                    <th>${translations.detailsMitreConfidenceLabel}</th>
                    <th>${translations.detailsMitreMapSource}</th>
                </tr>
                ${tactic
                  .map(tec => {
                    return `<tr>
                            <td><li>${tec.TEC}</li></td>
                            <td>${tec.MAP_C.toUpperCase()} ${
                      translations.detailsMitreConfidence
                    }</td>
                            <td>${
                              mapSource < 55
                                ? mapSource
                                : `${mapSource.slice(0, 55)}...`
                            }</td>
                            <td>${
                              tec.MAP_EN
                                ? translations.detailsEnabled
                                : translations.detailsDisabled
                            }</td>
                        </tr>`;
                  })
                  .join("")}
              </table>`;
            return `<div class="mitre-mapping ${confidence}" datatooltip="${tooltipContent}">${tacticName}</div>`;
          } else {
            const tooltipContent = `<div class='mitre-tooltip__first-row'>
              <div><span class='bold'>${
                translations.detailsMitreTactic
              }</span> ${tacticName}</div>
              <div>${tactic[0].MAP_C.toUpperCase()} ${
              translations.detailsMitreConfidence
            }</div>
              <div>${
                tactic[0].MAP_EN
                  ? translations.detailsEnabled
                  : translations.detailsDisabled
              }</div>
              </div>
              <div><span class='bold'>${
                translations.detailsMitreMapSource
              }</span></div>
              <div>${
                mapSource.length < 55
                  ? mapSource
                  : `${mapSource.slice(0, 55)}...`
              }</div>`;
            return `<div class="mitre-mapping mitre-${tactic[0].MAP_C}" datatooltip="${tooltipContent}">${tacticName}</div>`;
          }
        })
        .join("");
    }
  } else {
    document.getElementById(
      "mitre-mappings__container"
    ).innerHTML = `<p>${translations.detailsNotFound}</p>`;
    document.getElementById("mitre-section__view-toggle").style.display =
      "none";
  }

  // Groups
  document.getElementById("groups__list").innerHTML =
    rule.GR && rule.GR.length
      ? `<li>${rule.GR.join("</li>\n<li>")}</li>\n`
      : translations.detailsNotFound;

  // Rule action
  document.getElementById("rule-action__list").innerHTML =
    rule.AD && JSON.parse(rule.AD).length
      ? `<li>${JSON.parse(rule.AD).join("</li>\n<li>")}</li>\n`
      : translations.detailsNotFound;

  // Rule response
  if (rule.RED && JSON.parse(rule.RED).length) {
    const ruleResponseArray = JSON.parse(rule.RED);
    document.getElementById("rule-response__list").innerHTML = `<li>${
      ruleResponseArray[0]
    }<ul>${ruleResponseArray
      .slice(1)
      .map(res => {
        return `<li>${res}</li>`;
      })
      .join("")}</ul></li>\n`;
  } else {
    document.getElementById(
      "rule-response__list"
    ).innerHTML = `<p>${translations.detailsNotFound}</p>`;
  }

  // Rule limiter
  if (
    rule.rule_data &&
    rule.rule_data.rule &&
    rule.rule_data.rule.limiter &&
    rule.rule_data.rule.limiter[0]._$
  ) {
    const limiter = rule.rule_data.rule.limiter[0]._$;
    const TIME_MAP = {
      s: translations.detailsRuleLimiterSeconds,
      m: translations.detailsRuleLimiterMinutes,
      h: translations.detailsRuleLimiterHours
    };
    document.getElementById(
      "rule-limiter__text"
    ).textContent = translations.detailsRuleLimiterText
      .replace("{0}", limiter.responseCount)
      .replace("{1}", limiter.intervalCount)
      .replace("{2}", TIME_MAP[limiter.intervalType])
      .replace("{3}", limiter.hostType);
  } else {
    document.getElementById("rule-limiter__text").textContent =
      translations.detailsNotFound;
  }

  // Rule details table
  const dateUpdated = new Date(rule.date_modified);
  const dateCreated = new Date(rule.date_created);
  document.getElementById(
    "rule-details__type"
  ).textContent = `${rule.type.toLowerCase()} rule`;
  document.getElementById("rule-details__owner").textContent = rule.owner;
  document.getElementById(
    "rule-details__updated"
  ).textContent = `${dateUpdated.toLocaleDateString(undefined, dateOptions)}`;
  document.getElementById("rule-details__origin").textContent = rule.origin;
  document.getElementById(
    "rule-details__created"
  ).textContent = `${dateCreated.toLocaleDateString(undefined, dateOptions)}`;
  document.getElementById("rule-details__category").textContent = rule.RC;
  document.getElementById("rule-details__id").textContent = rule.id;
  document.getElementById("rule-details__uuid").textContent = rule.uuid;

  // Custom attributes
  document.getElementById("custom-attributes__list").innerHTML =
    rule.CRAList && rule.CRAList.length
      ? rule.CRAList.map(attribute => {
          return `<li><div class="custom-attributes__item">${
            attribute.name
          }</div>
            <div class="custom-attributes__value-list">
            ${attribute.valueList
              .map(value => {
                return `<div class="custom-attributes__value">${value}</div>`;
              })
              .join("")}
              </div></li>`;
        }).join("")
      : translations.detailsNotFound;

  // UBA risk score
  if (rule.URSK) {
    document.getElementById("uba-risk-score__div").style.display = "block";
    document.getElementById("uba-risk-score__value").textContent = rule.URSK;
  } else {
    document.getElementById("uba-risk-score__div").style.display = "none";
  }

  // Dependencies
  document.getElementById("dependencies__list").innerHTML =
    rule.dependencies && rule.dependencies.length
      ? rule.dependencies
          .map(dependency => {
            return `<li
              ${
                rulesObj[dependency.uuid]
                  ? `onclick="openRule('${dependency.uuid}')" class="link"`
                  : ""
              }
              >
                ${dependency.name}
              </li>\n`;
          })
          .join("")
      : translations.detailsNotFound;

  // Dependents
  document.getElementById("dependents__list").innerHTML =
    rule.dependents && rule.dependents.length
      ? rule.dependents
          .map(dependents => {
            return `<li
              ${
                rulesObj[dependents.uuid]
                  ? `onclick="openRule('${dependents.uuid}')" class="link"`
                  : ""
              }
              >
                ${dependents.name}
              </li>\n`;
          })
          .join("")
      : translations.detailsNotFound;

  // Log source types
  document.getElementById("log-source-types__list").innerHTML =
    rule.LST && rule.LST.length
      ? `<li>${rule.LST.join("</li>\n<li>")}</li>\n`
      : translations.detailsNotFound;

  if (rulesObj.reportInfo.includeVisualization) {
    getVisualization(rule);
  }

  onReady();
};

const openWelcomePage = () => {
  const selectedRuleListItem = document.getElementById(selectedRuleId);
  selectedRuleListItem && selectedRuleListItem.classList.remove("selected");
  selectedRuleId = null;

  // Hide rule details
  document.getElementById("rule-details-screen").style.display = "none";
  document.getElementById("welcome-screen").style.display = "block";
};

const toggleMitreView = () => {
  showMitreTileView = document.getElementsByClassName("toggle-input")[0]
    .checked;
  openRule(selectedRuleId);
};

const Tooltip = {
  create(tt, elm) {
    // elmEdges relative to the viewport.
    elmEdges = elm.getBoundingClientRect();
    elmTop = elmEdges.top + elmEdges.height;
    tooltipHTML = elm.getAttribute("datatooltip");
    tt.innerHTML = tooltipHTML;
    if (elmEdges.left > window.innerWidth - 300) {
      tt.className = "tooltip-container tooltip-left";
    } else if (elmEdges.left + elmEdges.width / 2 < 300) {
      tt.className = "tooltip-container tooltip-right";
    } else {
      tt.className = "tooltip-container tooltip-center";
    }
  },
  position(tt) {
    const viewportEdges = window.innerWidth - 300;
    const centered = elmEdges.left + elmEdges.width / 2 - tt.offsetWidth / 2;
    // Position tooltip on the left side of the elm if the elm is to
    // close to the viewports right edge
    if (elmEdges.left > viewportEdges) {
      tt.style.left = `${elmEdges.left - tt.offsetWidth - 20}px`;
      tt.style.top = `${elmEdges.top}px`;
      // Position tooltip on the right side of the elm.
    } else if (elmEdges.left + elmEdges.width / 2 < 300) {
      tt.className = "tooltip-container tooltip-right";
      tt.style.left = `${elmEdges.left + elmEdges.width + 20}px`;
      tt.style.top = `${elmEdges.top}px`;
      // Position the tooltip above the element if there is not enough bottom space
    } else if (elmTop + 10 + tt.offsetHeight > window.innerHeight) {
      tt.className = "tooltip-container tooltip-center-bottom";
      tt.style.left = `${centered}px`;
      tt.style.top = `${elmTop - tt.offsetHeight - 35 + window.scrollY}px`;
    } else {
      // Position the tooltip in the center of the elm.
      tt.style.left = `${centered}px`;
      tt.style.top = `${elmTop + 10 + window.scrollY}px`;
    }
  }
};

const showTooltipHover = evt => {
  const item = Object.create(Tooltip);
  const elm = evt.currentTarget;

  item.create(tooltip, elm);
  item.position(tooltip);
};

const hideTooltip = () => {
  tooltip.className = "tooltip-container no-display";
  tooltip.innerHTML = "";
  tooltip.removeAttribute("style");
};

const hideTooltipHover = () => {
  hideTooltip();
};

const hideTooltipClick = evt => {
  if (!evt.target.hasAttribute("datatooltip")) hideTooltip();
};

const getVisualizationList = rule => {
  if (
    rule.dependencies &&
    rule.dependencies.length &&
    !nodes.find(t => t.id === rule.uuid)
  ) {
    nodes.push({
      color: "#b270ff",
      id: rule.uuid,
      label: rule.name,
      title: rule.name
    });
    rule.dependencies.forEach(dep => {
      edges.push({
        from: rule.uuid,
        to: dep.uuid
      });
      getVisualizationList(rules[dep.uuid]);
    });
  } else if (!nodes.find(t => t.id === rule.uuid)) {
    nodes.push({
      color: "#b270ff",
      id: rule.uuid,
      label: rule.name,
      title: rule.name
    });
  }
};

highlightSelectedNode = values => {
  console.log(values);
  values.borderColor = "#1191E6";
  values.borderWidth = 3;
};

const getVisualization = rule => {
  nodes = [];
  edges = [];

  getVisualizationList(rule);

  // create a network
  var container = document.getElementById("visualization__graph");
  var data = {
    nodes: nodes,
    edges: edges
  };

  const defaultOptions = {
    autoResize: true,
    height: "100%",
    width: "100%",
    layout: {
      randomSeed: 0,
      hierarchical: {
        enabled: true,
        sortMethod: "directed",
        direction: "LR",
        levelSeparation: 300,
        nodeSpacing: 100,
        treeSpacing: 100
      }
    },
    edges: {
      // line colors
      color: { color: "black" },
      arrows: {
        to: true
      }
      // chosen: { label: false, edge: this.highlightSelectedEdge }
    },
    nodes: {
      shape: "box",
      margin: 10,
      widthConstraint: {
        minimum: 50
      },
      heightConstraint: {
        minimum: 30
      },
      shapeProperties: {
        borderRadius: 20
      },
      font: {
        color: "white"
      },

      chosen: { label: false, node: this.highlightSelectedNode }
    },
    physics: {
      enabled: false
    },
    interaction: {
      hover: true,
      navigationButtons: true,
      keyboard: {
        enabled: true,
        bindToWindow: false // Disables keyboard controls when graph loses focus
      }
    }
  };

  network = new vis.Network(container, data, defaultOptions);
  network.on("selectNode", function(properties) {
    var id = properties.nodes[0];
    openRule(id);
  });
  network.on("hoverNode", function(params) {
    network.canvas.body.container.style.cursor = "pointer";
  });

  network.on("blurNode", function(params) {
    network.canvas.body.container.style.cursor = "default";
  });
  document.getElementById("visualization__title").innerText =
    translations.dependencyTree;
};

const onReady = () => {
  tooltip = document.documentElement.querySelector(".tooltip-container");
  const tooltipElms = document.documentElement.querySelectorAll(
    "[datatooltip]"
  );

  Array.prototype.forEach.call(tooltipElms, elm => {
    elm.addEventListener("mouseover", showTooltipHover);
    elm.addEventListener("mouseout", hideTooltipHover);
  });

  if (tooltip) {
    document.addEventListener("click", hideTooltipClick);
  }
  hideTooltip();
};

// Code for Spliter
const dragElement = (element, direction, rulesObj) => {
  let md; // remember mouse down info
  const first = document.getElementById(
    element.id === "panel-separator--outer"
      ? "left-panel--outer"
      : "left-panel--inner"
  );
  const second = document.getElementById(
    element.id === "panel-separator--outer"
      ? "right-panel--outer"
      : "right-panel--inner"
  );

  const onMouseDown = e => {
    md = {
      e,
      offsetLeft: element.offsetLeft,
      offsetTop: element.offsetTop,
      firstWidth: first.offsetWidth,
      secondWidth: second.offsetWidth
    };

    document.onmousemove = onMouseMove;
    document.onmouseup = () => {
      document.onmousemove = null;
      document.onmouseup = null;
    };
  };

  element.onmousedown = onMouseDown;

  const onMouseMove = e => {
    const delta = {
      x: e.clientX - md.e.clientX,
      y: e.clientY - md.e.clientY
    };

    if (direction === "H") {
      // Horizontal
      // Prevent negative-sized elements
      delta.x = Math.min(Math.max(delta.x, -md.firstWidth), md.secondWidth);

      element.style.left = `${md.offsetLeft + delta.x}px`;
      first.style.width = `${md.firstWidth + delta.x}px`;
      second.style.width = `${md.secondWidth - delta.x}px`;
    }
  };
};

(function initialize() {
  dragElement(document.getElementById("panel-separator--outer"), "H", rulesObj);
  dragElement(document.getElementById("panel-separator--inner"), "H", rulesObj);
  document.getElementById("rule-details-screen").style.display = "none";
  document.getElementById("welcome-screen__export-name").textContent =
    rulesObj.reportInfo.exportName;
  const exportDate = new Date(rulesObj.reportInfo.date);
  document.getElementById(
    "welcome-screen__export-time"
  ).textContent = exportDate.toLocaleDateString(undefined, dateOptions);
  document.getElementById("welcome-screen__export-version").textContent =
    rulesObj.reportInfo.UCMVersion;
  document.getElementById("ucm-info__export-name").textContent =
    rulesObj.reportInfo.exportName;
  document.getElementById(
    "ucm-info__export-time"
  ).textContent = exportDate.toLocaleDateString(undefined, dateOptions);
  document.getElementById("ucm-info__export-version").textContent =
    rulesObj.reportInfo.UCMVersion;
  document
    .getElementById("search-bar__input")
    .addEventListener("keyup", filterRuleList);
  if (!rulesObj.reportInfo.includeVisualization) {
    document.getElementById("right-panel--inner").style.width = "0";
    document.getElementById("left-panel--inner").style.width = "100%";
    document.getElementById("left-panel--inner").style.maxWidth = "100%";
    document.getElementById("panel-separator--inner").style.display = "none";
  }
  setStaticStrings();
  filterRuleList();
  onReady();
})();
